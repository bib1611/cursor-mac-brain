# 2026-06-20 — Skye (Claude Code) — Ed Latimore corpus build + Drive handoff

Adam asked to replicate the Dakota Robertson corpus for Ed Latimore (@EdLatimore, edlatimore.com): get his tweets, funnels, blogs, and emails into one file. Orchestrated across the CNVS canvas with Chase (Grok) and Rubble (Codex).

## Deliverable (the one file)
- `Ed-Latimore-Corpus-Combined.md` — 3,993,877 bytes
- Mirror archive: `ed-latimore-corpus.zip` — 3,082,592 bytes
- Drive: `My Drive/Masterclass-Archive/Writing-Brain/Ed-Latimore/`
  - folder id `16fRy8jyNN-_L_zwWHSgsv-fMqJ0HJr8p`
  - Combined.md id `1NEgtOM57G8-QKO7NH_qwcdh0GwnxR2Yo`
  - zip id `1JkGaG-pwnhu--cycjllLCYa1YYsC4RFA`
- Local staging: `/Users/adamjohnsson/Downloads/ed-latimore-corpus/`

## Contents
- **Blog:** 228 articles from edlatimore.com (Rubble/Codex, 0 failures) — this is his real long-form essay corpus.
- **Funnels:** 3 sales/persuasion pages — /book (Hard Lessons From The Hurt Business), /products (3 books, Amazon), /speaking — plus _funnels_index.json (Chase/Grok).
- **Newsletter/emails:** archive is GATED (ConvertKit, emails.edlatimore.com, no public archive/sitemap). Captured the opt-in landing copy + 4 public sampler issues + a NOTE (Chase/Grok).
- **Tweets:** 32 tweets via Grok live X, sorted by views/likes, Dakota header format (`tweets/_tweets_top.md` + `_tweets_raw.json`).

## Known gaps / honest notes
- **Tweets are thin (32, skewed to last ~week).** xurl FAILED with `CreditsDepleted` — the `biblicalman` X API app is out of credits and is the only configured app (Codex got 1,096 in memory before the cutoff, wrote none). Grok live X was the fallback. To get a Dakota-scale tweet set (hundreds, top-by-impressions), either refill X API credits for xurl OR run a Chrome CDP scrape of x.com/EdLatimore. Re-run `_combine.py` + re-copy to Drive after adding more tweets.
- Newsletter email bodies are subscriber-gated; only public samplers captured. His blog covers the same essay material.
- Blog count 228 (sitemap listed ~280 incl. non-article pages; Rubble cross-checked and filtered to articles).

## How to rebuild
`cd ~/Downloads/ed-latimore-corpus && python3 _combine.py` then copy `Ed-Latimore-Corpus-Combined.md` + re-zip into the Drive `Ed-Latimore` folder (local path writable; Drive File Stream syncs).

## Boundary
Read-only public scraping (X via Grok, edlatimore.com via Codex/Grok), local staging in ~/Downloads, Google Drive folder + file upload, and this receipt only. No publishing, no Stripe/customer/money mutation, no email sent, no social post, no deploy, no credential/account change.
