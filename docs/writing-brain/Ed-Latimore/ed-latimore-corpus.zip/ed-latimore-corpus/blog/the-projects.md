# 5 things I learned growing up in the projects

- **Source:** https://edlatimore.com/the-projects
- **Date:** 2021-05-26T10:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 11001 chars

## Body (verbatim, study/swipe)

I lived in the projects for the first 18 years of my life. A crackhead almost killed me (read that story and more [here](https://edlatimore.com/crackhead)), I constantly got into fights, and I even saw a guy get killed.

It was a tough place to grow up. And while I’ve done well since leaving, my time in the ghetto taught me a lot about life.

This image is from a recent news story about a kid who got shot in Northview Heights. I grew up a few blocks from that building.

## What are the projects?

Before we get into the nitty-gritty of my ghetto wisdom, I realize some of you probably don’t know what the projects are.

The projects are areas of subsidized housing where rent is based on income.

This creates affordable housing for people who would otherwise be homeless. For the sake of cost and efficiency, there are rows and high-rises of identical homes and buildings.

Most public-housing residents aren’t bad people, but there are enough bad apples to ruin the whole basket. [Along with low-cost public housing comes an increased crime rate](https://www.city-journal.org/html/how-public-housing-harms-cities-12410.html).

As a result, the projects can be dangerous. Drug-fueled gang violence and poverty-motivated petty theft make most public housing projects a seriously rough place to live in.

## Are ghettos and the projects the same thing?

Most people use these terms interchangeably with “the ghetto” or “the hood.” But not all hoods and ghettos are public housing projects.

Housing projects tend to be the worst kind of ghetto — you gotta be a special kind of broke to live where the government subsidizes your rent and utilities.

**To me, they all mean the same thing:** a fucked up place that I would never want to live in again.

But I made it out.

Actually, “survived” is more accurate because many things can imprison you in the hood forever. I could have gotten a girl pregnant as a teen, been arrested, or been killed.

It wasn’t easy, but I avoided all these things.

I learned things from that environment which gave me a significant advantage in a civilized society. And the things I learned are very different from anything you’d find in a book.

This is the type of education you can only experience, survive, and then say to yourself, “never again.”

## 5 lessons I learned growing up in the projects

Let’s get into my experience growing up in the projects and what I learned from it.

## Good manners go a long way in the hood

I fought a lot as a kid. That’s just par for the course when you grow up in the projects.

I would have fought a lot more if it wasn’t for one simple phrase: “My bad.”

For those who don’t speak hood, “My bad” is the equivalent of saying “I’m sorry.”

You bump somebody in a crowd? “My bad” goes a long way. Step on someone’s foot on a crowded bus? He might get mad, but you can often defuse the situation by just saying “My bad.”

People don’t have a lot to lose, and you never know who gives a fuck and who doesn’t.

While not everyone has a gun, they might not care about an assault charge to defend their honor. (This assumes you call the cops, which everyone in the ghetto avoids: it just makes things worse.)

Through a powerful negative feedback loop, I learned that treating people with respect is better no matter the situation. I continue to do this to this day and has rewarded me tenfold throughout my life.

***[Read:*** [***“How to avoid a fight, and what to do if you can’t”***](https://edlatimore.com/how-to-win-a-street-fight)***]***

## In the ghetto, safety and security is an illusion

When you grow up in the ghetto, you never feel safe.

My house had doors and locks.

That didn’t keep people from breaking in and stealing shit. When I was 11, I got robbed by a crackhead at knifepoint for a calzone.

How does that help me now? I internalized something at a very young age: **nothing is ever safe.**

People will rob or try to hurt you, even if you never thought they would.

It teaches you to value everything you have and take extra care to protect the things you love the most.

The guy who robbed me looked a little like this

## Life can always get worse

My home situation was slightly better than average compared to the typical ghetto home life.

My mom didn’t always work, but she took temp work when she could, and I never went hungry.

Life wasn’t good, but I only had to look at some of my classmates to see that it could be *much* worse.

The thing about living in the projects is that everyone knows a lot about everyone. You know whose mom is a crackhead, prostitute, or drug dealer. Everyone’s life is pretty fucked up, but some people are way worse off.

I have many fond memories of playing Sonic 3 with my friends.

I used to have a friend that had all the newest video games. I remember spending hours playing Sonic on the SEGA Genesis. It was great fun, don’t get me wrong, but his family could barely afford to eat.

My mom decided to spend money on food rather than games—a wise decision in the long run.

What’s the lesson here?

Living next to other people with problems can drag you down. But, on the flip side, it can foster tremendous gratitude for the little things in life and show you that [your situation isn’t as bad as it seems](https://edlatimore.com/how-to-be-an-adult). Gratitude has tremendous value and I wrote about 6 reasons why you should be grateful in [this article](/6-reasons-to-be-grateful).

## Life is like poker: it’s about how you play the hand you’re dealt

Good starting cards help but don’t determine if you’ll win. They don’t even determine if you’ll survive the game.

There are lots of people born in the ghetto every year. Most continue the cycle and don’t make it out. A few do a little better but only barely.

Then there are those who make the ghetto a distant memory. I can proudly say that I am part of this last group.

But that shit ain’t easy. On top of the physical dangers, you must navigate, you must also undo lots of damaging programming, like attitudes about money.

I got $55,000 in insurance money [when my father died](https://edlatimore.com/absent-fathers). No one ever taught a broke project kid how to handle money. In 18 months, I was broke as hell and overdrawing my bank account.

Overcoming these challenges takes time, but once you beat them, you are invincible.

**It’s not easy, but anyone can change their life.** I’m proof of that.

## You make your own luck in life

When you become successful, nobody sees the hours of hard work you put in along the way.

“You’re so lucky!” A phrase you’ll hear time and time again if you make anything of yourself.

Was I lucky to get out of the ghetto? You bet I was. But, I didn’t get this luck from some divine power source.

I made my own luck.

Through discipline, grit, and the determination to escape the hellhole I was living in, I managed to build a life I was proud of.

Once you get on this path of self-improvement, something funny starts to happen.

**The harder you work, the luckier you get.**

As you become a high-value man, get more money, and stop thinking life is out to get you, things start to magically improve.

However, this is where 99% of people make a crucial mistake.

If you’re reading this thinking, “Ed, I work 60 hours a week, grinding every day, and never get anywhere, there’s no way you didn’t get lucky…”, you have to take a step back and think.

You’ll never succeed with the mindset that you’re destined to fail no matter what.

If you believe that anything is possible, the world will open up, and you’ll begin to see opportunities pop up in places you never expected.

This is why I wrote my book “[The Four Confidences](https://mind-and-fist.ck.page/4f65ddeea7).” I saw many guys getting pulled down, living every day like knee-deep in mud.

## Frequently asked questions about living in the projects

What are “the projects”?

“The projects” is slang for government-subsidized public housing, usually located in low-income urban areas. The term comes from public housing projects built to provide affordable housing for poor families. In American culture, “the projects” are often associated with poverty, crime, overcrowding, and difficult living conditions, although many hardworking families also live there.

  What does it mean to live in the projects?

Living in the projects means living in public housing where rent is subsidized based on income. In practice, the phrase often implies growing up in a low-income neighborhood with higher levels of crime, economic hardship, and instability. Depending on the city and environment, life in the projects can range from difficult to extremely dangerous.

  Are the projects and the hood the same thing?

Not exactly. “The hood” is a broader slang term for a poor or rough neighborhood, while “the projects” specifically refers to public housing developments. Many projects are located inside the hood, but not every hood contains public housing projects.

  Why are they called the projects?

They are called “the projects” because they were originally government housing projects—large-scale construction developments designed to provide affordable housing for low-income residents. Over time, the phrase became slang associated with urban public housing and the culture surrounding it.

  Are the projects dangerous?

Some projects are dangerous, while others are relatively stable communities. Historically, many housing projects became associated with gang activity, drug crime, poverty, and violence because of concentrated economic hardship and poor city management. However, experiences vary widely depending on the city, neighborhood, and time period.

  What does growing up in the projects mean?

Growing up in the projects usually means being raised in low-income public housing while dealing with financial stress, limited opportunities, and exposure to violence or instability. For many people, it also creates resilience, street smarts, adaptability, and a strong desire to escape poverty.

  What’s the difference between the projects and the ghetto?

The ghetto is a broader term for an impoverished or segregated neighborhood, while the projects specifically refer to government-funded public housing complexes. Housing projects are often located in ghettos, but not all ghettos are public housing developments.

  What do the projects look like?

Traditional housing projects often consist of rows of apartment buildings or high-rise towers built with uniform designs to maximize affordable housing. Many older projects were densely packed and poorly maintained, although some modern public housing developments are newer and safer than the stereotypical image associated with “the projects.”

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
