# Trimethylglycine (TMG) Benefits & Supplement Guide for Boxers (2025

- **Source:** https://edlatimore.com/trimethylglycine-benefits-for-boxers
- **Date:** 2025-04-22T16:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 14625 chars

## Body (verbatim, study/swipe)

Affiliate disclosure

This post contains affiliate links. If you purchase through my links, I earn a small commission at no extra cost to you. Thanks for supporting the site!

I’m Ed Latimore, a former heavyweight amateur national champion boxer and professional heavyweight once signed to Roc Nation Sports. I’ve boxing for over 15 years and sparred with the likes of Roy Jones Jr, Stipe Miocic, Dominic Breazeale, Michael Hunter, and some other names you may or may not know.

When I boxed as an amateur and professional, I didn’t even know what trimethylglycine (TMG) was. I’d never heard of it, either by that name or its other name, betaine. Most people in the athletic training world have never heard of TMG, but they are far more familiar with its more popular cousin, creatine.

So if bros in the gym weren’t using TMG and creatine—a supplement that receives all the hype from athletes and natural bodybuilders—is hardly ever used in boxing, the odds of me ever hearing about it from my fellow combat athletes was nill.

However, t now that I know a lot more about it, I believe that TMG should be a staple of every boxer’s supplement stack. And while this article focuses on the benefits that boxers can specifically attain, all athletes can get something from TMG. Based on what we’ve seen in the research, I don’t understand why it doesn’t receive all the hype that creatine gets.

I wish I had used it myself, but since I can’t go back in time, I’m doing the next best thing: using it now as I prepare for a comeback fight after 8 years off, and educating other boxers on why they need to incorporate it into their training routine. But before I can convince you of why you need to use it, I have to first explain what TMG is—and in case you don’t watch the entire video, the link to where I get a high quality TMG supplement is at the link in the pinned comment. It also comes with creatine, beta-alanine, and l-carnitine. I’ll be doing seperate videos on all those supplements, but just know that this is easily the best supplement that anyone involved in combat sports—not just boxing, or really any sport that requires sustained power output—can be use.

Now let’s do a deep dive on trimethylglycine, aka TMG, aka betaine.

## What is trimethylglycine (TMG)/betaine?

Trimethylglycine (TMG), also known as betaine, is a naturally occurring compound first isolated from sugar beets, which explains its alternative name. Throughout this article, I’ll refer to it as either betaine, trimethylglcine, or TMG.

This small molecule consists of three methyl groups attached to the amino acid glycine and serves multiple important biological functions in the human body

Trimethylglycine’s role as a methyl donor provides significant advantages to athletes through several key mechanisms. Methylation is a biochemical process where methyl groups (-CH3) are transferred to various molecules throughout the body.

For athletes, this process directly impacts performance by optimizing energy production pathways, enhancing protein synthesis, and accelerating recovery ([Craig, 2004](https://pubmed.ncbi.nlm.nih.gov/15321791/)). During intense training, athletes rapidly deplete methyl groups, potentially limiting cellular repair and energy metabolism.

TMG replenishes these critical methyl groups, supporting the creation of creatine and phosphatidylcholine, both essential for explosive power and cellular membrane integrity ([Trepanowski et al., 2011](https://pubmed.ncbi.nlm.nih.gov/22080324/)). The methylation process also helps regulate gene expression related to muscle adaptation and growth, potentially enhancing training responses ([Cholewa et al., 2013](https://pubmed.ncbi.nlm.nih.gov/23967897/)).

Additionally, by facilitating the conversion of homocysteine to methionine, TMG helps maintain healthy inflammation levels and cardiovascular function—crucial for sustained performance and recovery ([Lever & Slow, 2010](https://pubmed.ncbi.nlm.nih.gov/20346934/)). Without adequate methyl donors like TMG, athletes may experience compromised energy systems, slower recovery between sessions, and reduced capacity to adapt to training stimuli. This biochemical support system allows athletes to train more intensely, recover more completely, and adapt more efficiently to their training programs, creating a cumulative performance advantage over time [(Hoffman et al., 2009](https://pubmed.ncbi.nlm.nih.gov/19250531/)).

Trimethylglycine is one of the most well-researched supplements in the fitness world, but just like creatine, you rarely see boxers incorporate it into their supplement stack—and I’ve yet to meet a boxer who even knows what it is before I tell them. In this article, I aim to change that because if you found this article, you’re most likely a boxer. Or, at the very least, some type of combat athlete or athlete in general.

The rest of this article will explain why boxers need to take TMG and examine the numerous benefits. Before getting into it, we have to answer the question on every boxer’s mind when it comes to using a supplement.

## Is trimethylglycine allowed to be used in boxing?

The best part about TMG is that the World Anti-Doping Agency (WADA) approves its use, so you’re safe. Trimethylglycine is legal in professional and amateur boxing and is approved by all major athletic governing bodies. This supplement is expressly excluded from WADA’s “prohibited substance” lists and is widely accepted, both in and out of the combat sports community—despite many boxers not using it.

WADA, which sets international standards for anti-doping policies in all sports, explicitly permits TMG use at all levels of competition. All legitimate boxing regulatory bodies in the world follow the guidelines set by WADA, so a boxer never has to worry about a sanction or suspension if they take TMG.

## How TMG helps boxers and athlets

### Trimethylglycine enhances a boxer’s power output and explosive performance

TMG directly enhances a boxer’s methylation pathways, which play a crucial role in energy production during high-intensity activity in the ring. During explosive movements like combinations and power punches, [the body needs to quickly produce energy](https://edlatimore.com/mita-nutra-man-greens-review), and TMG helps optimize these processes.

According to research ([Hoffman et al., 2009](https://pubmed.ncbi.nlm.nih.gov/19250531/)), trimethylglycine supplementation increases power output by approximately 5-15%, allowing for more explosive punches and combinations. This enhanced power production is a significant performance advantage, translates to more impactful punches not just during exchanges but throughout the entire fight.

With TMG supplementation, boxers can maintain their explosive power for longer periods. Research has shown that TMG improves work capacity during high-intensity exercise, resulting in up to 10% more total work output than non-supplemented athletes ([Lee et al., 2010](https://pubmed.ncbi.nlm.nih.gov/20642826/)).

If you already hit harder, 10% harder can change the outcome a fight. Even if you’re less skilled and it’s into the later rounds. This sustained explosive capability means that not only does a boxer hit harder initially, but they also maintain that power deeper into fights. The boost in power endurance from betaine gives a boxer a significant advantage, and all with any drugs that are banned by WADA.

The advantage gets bigger in later rounds when opponents have depleted their energy reserves, reducing their punching power and punching output. This alone is a significant advantage in a high-intensity sport like boxing, but TMG has another fantastic property that pairs incredible well with the power advantage.

### Trimethylglycine improves recovery between training sessions

Recovery between training sessions is just as important as the training itself. TMG helps boxers recover faster and more completely between tough workouts, allowing for more frequent high-quality training sessions.

Supplementing with TMG is a game changer for boxers looking to perform better and train more effectively during camp. TMG significantly reduces markers of muscle damage after intense exercise ([Trepanowski et al., 2011](https://pubmed.ncbi.nlm.nih.gov/22080324/)). This makes it easier to recover because you’ve suffered less damage. It also allows you to push yourself harder because you’re more resistant to damage.

Studies have shown that athletes supplementing with TMG experience reduced creatine kinase levels (a marker of muscle damage—you can get it and other important [blood markers measured here](https://capitaloneshopping.com/s/walkinlab.com/coupon)) after intense exercise, indicating less muscle damage and faster recovery ([Apicella et al., 2013](https://pubmed.ncbi.nlm.nih.gov/22976217/)). This same study also showed significant increases in IGF-1 and growth hormone, along with a decrease in cortisol. These biomarkers indicate significant protein synthesis and muscle recovery.

TMG acts as a methyl donor in the body, enhancing protein synthesis and cellular repair. When you train intensely, muscle tissue gets damaged and requires efficient repair. TMG helps optimize these repair mechanisms through its role in methylation.

Methyl groups are essential for several of these biochemical reactions related to recovery and adaptation. During high-intensity training like boxing sessions, the body depletes these methyl groups quickly, potentially limiting recovery capacity ([Craig, 2004](https://pubmed.ncbi.nlm.nih.gov/15321791/)).

By enhancing methylation capacity, TMG allows boxers to recover more quickly between sessions, reducing soreness and accelerating muscle repair. This means you can train with more intensity and, as an added bonus for amateur boxers, you can recover faster during multiday tournaments..

### Trimethylglycine helps boxers maintain optimal body composition

Weight management is critical in boxing. Coming in too heavy can disqualify you from competing while coming too light gives up a significant advantage to your opponent. Furthermore, it’s not just about the number on the scale, but how that weight is distributed. There’s a world of difference between one pound of muscle and fat.

Betaine is great for maintaining optimal body composition. Unlike some supplements that cause water retention (like creatine), TMG helps with proper hydration without excessive water weight. But handling water weight is only one part of the weight management equation for boxers, and it becomes less important the higher you go in weight classes.

Trimethylglycine supplementation helps boxers increase muscle and decrease body fat, optimizing body composition. TMG does this by optimizing fat metabolism and potentially enhancing lean muscle preservation during weight cutting ([Cholewa et al., 2013](https://pubmed.ncbi.nlm.nih.gov/23967897/)).

TMG helps maintain cellular hydration during weight cuts, which is vital for preserving performance capacity. When properly hydrated, cells function optimally even when overall body water is reduced. This means better performance during the final training sessions before a weigh-in and better rehydration capacity after making weight.

Additionally, TMG helps regulate homocysteine levels in the body. Elevated homocysteine can impair recovery and has been linked to increased inflammation. By maintaining healthy homocysteine levels, TMG creates an internal environment more conducive to optimal body composition and recovery ([Holm et al., 2003](https://pubmed.ncbi.nlm.nih.gov/15550695/)).

### Trimethylglycine Supplement Dosage and Timing

Taking TMG post-workout with food enhances absorption Hydration: Maintain normal water intake during supplementation periods Food Intake: Pair with meals to improve tolerance Type Selection: Anhydrous TMG powder is the most well-researched and cost-effective form

Most importantly, boxers should test their response to TMG during off-season or early in training camp to understand personal response patterns before implementing this protocol during fight preparation.

## Final thoughts on why boxers should use trimethylglycine

The greatest advantage of TMG for boxers is that it enhances power output, supports recovery between sessions, and helps maintain optimal body composition. Unlike some other supplements, TMG doesn’t typically cause water retention issues that might interfere with making weight.

Assuming you’re active in your training and you have a lifestyle and habits that support your training, TMG will provide performance benefits without unwanted side effects. Boxers in all weight classes can benefit from TMG supplementation without worrying about weight management complications.

## Best TMG Supplement for boxers and athletes

I get my [TMG from Simply Nootropics.](https://simplynootropics.com/products/tmg-powder?utm_source=brand_ambassador_ads&utm_ambassador=edlatimore&utm_medium=social&utm_location=us_uk&platform=grin&link_id=1988229&token=XYSJXDV2ucCDxfNIln8EJmRoBfH4O6hL&contact_id=4b3bfa60-7e24-4707-b26e-62b3e2bdbc3d&attribution_window=30) Their product comes in an easy to store, highly durable can. If you grab a can from my link, I get a small commission at no extra charge to you. If this article helped you to add TMG to your training stack, think of it as saying thank you.

[***Purchase here***](https://simplynootropics.com/products/tmg-powder?utm_source=brand_ambassador_ads&utm_ambassador=edlatimore&utm_medium=social&utm_location=us_uk&platform=grin&link_id=1988229&token=XYSJXDV2ucCDxfNIln8EJmRoBfH4O6hL&contact_id=4b3bfa60-7e24-4707-b26e-62b3e2bdbc3d&attribution_window=30)

If you really want to supercharge your training, consider adding [creatine](/why-boxers-need-to-take-creatine) and beta-alanine to your TMG stack. It will take your energy levels even further and give you more punching power to boot. You can learn more about creatine for boxers in this article and beta-alanine for boxers in this article.

Or, if you already know about them and you’re tired of mixing and buying your supplements separately, check out [Mita Nutrition’s “Power.”](/best-supplements-for-boxing#boxing-supplement-for-punching-power-mita-power) Each serving contains 5 grams of creatine, 2 grams of trimethylglycine, and 3.6 grams of beta-alanine.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
