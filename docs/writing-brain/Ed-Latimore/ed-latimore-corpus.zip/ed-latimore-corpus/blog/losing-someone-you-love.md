# Dealing with the death of a relative

- **Source:** https://edlatimore.com/losing-someone-you-love
- **Date:** 2022-03-08T15:00:47.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 10574 chars

## Body (verbatim, study/swipe)

Losing someone you love is never easy.

The pain of loss can send you into an emotional roller coaster that’s hard to deal with…

Even if you had a bumpy relationship with your loved one like I did with my mom.

If you’ve been following me for a while or are signed up for my newsletter, you’ll likely know that I lost my mother in December, the Saturday before Christmas.

Whether you feel anger, sadness, regret, relief, or all of the above, losing someone as significant as a parent or close family member leaves you in a surreal state. Often you’re not sure how to feel or how to move forward.

This article will provide tips on how to cope with losing someone you love and handling the confusing emotions that come up.

## Accept how you feel

Everything is okay.

I know this sounds like a blanket pacifying statement that everyone hears when something goes wrong. But in this context, it means that everything you feel is the right way to feel. For many, losing a loved one like a family member or close friend is the worst thing that will ever happen to them. Birth and death have a way of putting life into perspective and forcing you to face emotions and circumstances you only encounter during these events.

There’s no easy button where you can avoid reality and not have to pay for it later. You have to move through the emotions to get through the emotions. If you’re angry, sad, in denial, relieved, it’s all okay to feel. And everyone’s grief experience is different. Some will have a more difficult time with it than others.

Add to this that relationships with parents aren’t always the sunshine and rainbows it is in sitcoms. [I fought constantly with my mother](https://edlatimore.com/raised-by-single-mom) to give up smoking and take better care of herself.

However, our rocky relationship certainly didn’t give me a *get out of jail free card* with grief Eventually, I learned that she was just doing the best she could.

Read more about how I learned to forgive my mother in [How to forgive your parents.](https://edlatimore.com/how-to-understand-and-forgive-your-parents)

## Let the helpers help

Depending on your age, you might remember Mr. Rogers. He was a nice, old white guy that came on early in the morning right before Barney. His mantra was, *“It’s a beautiful day in the neighborhood.”* Well, Mr. Rogers had this saying once, that when things go wrong…

```
>>>“Look for the helpers. You will always find people helping.”
```

Well, in the days following my mom’s passing, I wasn’t coping. But I thought I was. I didn’t reach out for help or even tell close friends because I was dealing with it on my own, in my own way.

It actually took my fiance calling my friends for me to realize you shouldn’t face grief alone. And my friends showed up for me like they always have over the last decade-plus of our relationship. I needed their grief support without realizing that I did.

What do you gain by suffering in isolation? Not a damn thing.

And you know by now isolation is a gateway to addiction with stress and hard emotions as the lubricant.

Often we don’t reach out because we feel we should be strong enough to handle it on our own. Or you might feel your grief will be a burden to others.

That said, if someone is trying to help, let them. Even if it’s buying you food. Let them help.

## Don’t mourn the loss before they’re gone

In the months leading up to my mother’s passing, I got to spend one to two hours a day in the hospital with her. It was time I feel grateful to have. Time I recognize most people don’t get.

While someone is alive and thriving, we put off spending quality time and seeing them because of the fallacy of thought, “I can see them later.”

But the truth is, death is a part of life. And later might never come.

Hearing that someone is dying can send you into the mourning process before they’ve even passed on to the other side. This is called anticipatory grief.[1](#fn:1) Basically, you start going through the early stages of grief in anticipation of the loss.

Though it’s natural to feel, it steals your mind away from the present moment and the fact that you still have time to spend with your loved one.

One or two hours a day is plenty to laugh about old memories or talk about nonsense. It’s up to you to use your time wisely.

## Maintain your habits as much as you can

Death isn’t always sudden. Sometimes it lingers and your loved one goes into hospice care for a few days and comes home. Or they may be in and out of the hospital the last year of their lives. Your loved one may get a diagnosis of a few days to live and end up living for several more years.

During these times you can feel suspended in time either waiting for them to get better or waiting for the news of their passing. Either way, you aren’t sure if you can start the grieving process or what life changes to anticipate. This can create strain on your emotional and physical health for extended periods of time making it easy to drop all your habits and become reactionary to everything.

Try to fight this as much as you can. Even if you have to fly to a new location to see someone, try to maintain some sense of normalcy.

It’s okay to take the time off from work or the time away that you need, whether it’s a week or a month. But don’t let your habits drop forever. Try to maintain your morning routine or a favorite activity. This will give you some grounding during those times you feel uncertain.

## Don’t map your grief

Don’t wait around for it to be over before you resume your life. Grief doesn’t have a timetable. And despite the stages of grief, grief isn’t actually linear. You may skip all the phases and shoot straight to anger.

When I lost my dad at 18, grief was a slow process. I was fine for several months then all of a sudden I was sobbing in a conversation about him.

Depending on the relationship you have with someone, the grieving process can be shorter or longer. The pain of losing a loved one can be more intense causing heartbreak, severe mental health issues, and physical symptoms.[2](#fn:2) Grief can also be mild, causing periodic sadness but not disrupting your days. Either way, it can strike randomly without real warning.

Grief manifests in many forms with everyone having a different grief experience. Mental and physical symptoms of grieving include:

- Fear
- Periodic sadness
- Anger
- Guilt
- Shock or numbness
- Fatigue
- Aches and pains
- Weight loss/gain

## Recognize if you’re not dealing with it

There is a medical term to describe grief that lingers and becomes almost a delusion for the person experiencing it called complicated grief.[3](#fn:3) It ranges from being unable to resume any life activities to being in complete denial that your loved one is gone.

Complicated grief is a sign that you are not coping with reality. Though many experience intense sadness during grief, depression is actually a sign that you are not coping well. For others, you may feel completely detached from a loss then have an explosion that is out of character for you.

Signs you aren’t coping well:

- Intense longing for prolonged periods of time
- Explosions out of nowhere
- Addictive behaviors
- Self-harm
- Substance abuse
- Not resuming regular activities
- Apathy
- Depression

If you are struggling with complicated grief, signup for grief counseling or a grief support group. You manage the physical symptoms by ensuring your body has all the nutrients it needs. You can also try:

- Talking to a close friend.
- Getting out of the house
- Resuming the activities you once loved
- Writing a letter to your loved one
- Talking about your favorite memories with a surviving relative

## What to do when losing someone you love

The pain of losing someone you love is one of the worst things most of us will experience. Even if you weren’t close to your loved one, you still feel the effects of their passing. You may go through a roller coaster of emotions or only experience the physical symptoms of the grieving process. Regardless of the intensity, your life changes, even if only in perspective.

If you’re struggling with losing someone you love and don’t know what to do, try this:

1. Know that how you feel is the right way to feel
2. Let close friends and family members help you
3. Anticipatory grief is normal but don’t let it steal your gratitude for the moment
4. Maintain your habits as much as possible
5. Don’t wait around for grief to be over
6. Know the signs that you’re not coping and seek help

## Get Your Life Together With The Essays of Power

I don’t know you, but I know you.

I know that you’re tired of feeling weak, being a victim, and having no control over the direction of your life.

I know you because I was once you.

I used to be stuck on the hedonistic treadmill of mediocrity. Always drunk, always broke, and always looking for the next piece of cheap entertainment and distraction.

Then one day, I changed my entire life around.

I took responsibility for my personal development and started living the best life I possibly could. I learned how to:

- Live with purpose
- Think with clarity
- Face the my demons
- Fix my finances

Unlike a lot of other motivational gurus, I’ve been to the bottom and I clawed my way back out. It wasn’t easy and I wasn’t sure if I’d just become another statistic along the way, but I think I have made tremendous progress.

I learned the hard way, but I can break it down so you can learn it the easy way…

 [Get The Mind And Fist Essays Of Power](https://gum.co/GDlZd)

---

### References

1. Eldridge, Lynne MD Medically reviewed by Adjoa Smalls-Mantey, MD, DPhil. *VeryWell Health: \_How Anticipatory Grief Differs From Grief After Death*. \_Updated on November 05, 2021 <https://www.verywellhealth.com/understanding-anticipatory-grief-and-symptoms-2248855> [↩](#fnref:1)
2. Hairston, Stephanie. Medically Reviewed by Neha Pathak, MD.*WebMD:* How Grief Shows Up In Your Body. July 11, 2019 <https://www.webmd.com/special-reports/grief-stages/20190711/how-grief-affects-your-body-and-mind> [↩](#fnref:2)
3. June 19, 2021: Mayo Clinic Staff; Mayo Clinic: Complicated Grief <https://www.mayoclinic.org/diseases-conditions/complicated-grief/symptoms-causes/syc-20360374> (accessed March 2022) [↩](#fnref:3)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
