# How to be chill in 5 steps

- **Source:** https://edlatimore.com/how-to-be-chill
- **Date:** 2020-06-05T20:09:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 9427 chars

## Body (verbatim, study/swipe)

A year ago I taught a friend how to drive. If you’ve never done it, teaching a person how to drive is one of the most stressful situations you can ever experience.

If you have a hard time trusting people, then you should definitely not do this.

I’ve taught two adults how to drive and I can tell you that most people don’t consider what a big deal it is that each year, millions of high school kids get their driver’s license without their parents having a heart attack.

I’m naturally a laid back, relaxed, and chill person, but even my stress levels were elevated. However, I still managed to stay calm, cool, and collected. Never once did I let my headspace get infected with crazy “what if” scenarios about being in a car crash.

As a teacher, this is important.

If I get terrified, I’ll shout. If I shout, I damage their self-esteem about driving and I make it more likely that they’ll make a mistake.

Being chill like this, even in the face of a dangerous situation, is a valuable skill that I think everyone should learn for the sake of their mental health and well-being.

## A Chill Person Doesn’t Let The Little Things Bother Them

The friend I was teaching to drive remarked that I never get angry. “You’re super chill and nothing ever seems to bother you.”

While this isn’t EXACTLY true, I do have a remarkably even temper. Very few things have the power to make me angry. In fact, I so rarely get angry that I physically feel the effects of anger for almost 24 hours after, much like a bad hangover.

It takes time and lots of deep breaths to get me feeling normal again. I have a hard time getting mad but once I do, I’m also pretty quick to chill out.

I suspect that this is related to another trait of mine: nearly non-existent neuroticism.

Dr. Jordan Peterson has [a test that measures the Big 5 personality traits](https://www.understandmyself.com/), and I scored in the 0th percentile for neuroticism. I read up on characteristics of neuroticism, and that seems like an accurate assessment of my character.

Neuroticism is described by Wikipedia this way:

“Individuals who score high on neuroticism are more likely than average to be moody and to experience such feelings as anxiety, worry, fear, anger, frustration, envy, jealousy, guilt, depressed mood, and loneliness”

Most people are aware of the traits of neuroticism and anxiety. If you aren’t, this short anecdote will sum it up nicely:

Someone asked on Twitter if I ever get afraid and another person who saw me post my Big 5 personality results responded, “He is several standard deviations below the average in neuroticism. He legitimately doesn’t experience negative emotions like the rest of us.”

I legit don't get bothered by most things. At least not like most people.

That made me laugh and feel invincible, but it’s not the entire truth. While I rarely experience those negative emotions, it happens. I just know how to deal with them. As a result, [I experience far less stress](https://edlatimore.com/mita-nutra-man-greens-review) in my life than the average person.

This article will teach the techniques I use to remain “super chill” and calm even when things get crazy.

## How to be chill in 5 steps

## 1) Show gratitude

This is the number 1 secret to my chillness.

I’ve been to the bottom several times in my life. I’m grateful to be alive and still here despite all that I’ve experienced. If you struggle with being grateful then check out my [6 reasons to be gateful](https://edlatimore.com/6-reasons-to-be-grateful).

I was born with almost [every statistical disadvantage against me](https://edlatimore.com/how-childhood-trauma-affects-adulthood-the-most-important-thing-you-can-t-remember), yet I’m still here and flourishing. It’s impossible for me to have a bad day because I know how bad the days can truly be.

When something goes wrong, this gratitude allows me to ask myself, “Could it be worse?”. If I’m not in prison or dead, the answer is always “Yes!”. Many people know how much of a mindset shift gratitude can cause, but they don’t understand the discipline of the practice.

Whenever something happens to you, good or bad, train yourself to immediately ask if it could be worse. If you have your health and freedom, you have the ability to improve any situation.

## 2) Have a growth mindset

I used to have a fixed growth mindset.

[A lot of my woes in childhood](https://edlatimore.com/absent-fathers) come back to the idea that if I wasn’t good at something, there was no hope for me to ever be better at it. It wasn’t until I started boxing that I began to see that it’s possible to improve your abilities beyond what you first started with. It’s just one of several benefits of boxing, rea all the benefits [here](https://edlatimore.com/boxing-benefits).

With a growth-based mindset, you believe that you can–with enough effort and time–learn and do anything. Obviously, there are genetic limitations that will keep many from becoming the best at something, but it’s not necessary to be the best at anything; only to be the best version that you can be.

As a result of my growth-based mindset, I don’t believe that anything is out my grasp. All I have to do is practice. This means that there is no reason for me to ever feel discouraged, envious, or limited. I can have or be almost anything.

## 3) Be patient

One cool thing about being a late bloomer in life is that you learn to appreciate the power of time.

Bad things happen quickly. Good things tend to take a while. When you understand this, you feel confident when something takes time to develop. In fact, you come to completely distrust anything that comes quickly and easily.

One reason that people get angry is that things don’t happen quickly enough. Many people tell me they feel anxious when they think something is about to happen. I look at time gaps between action to be an opportunity for rest, relaxation, recharge, and planning my next move.

Most importantly, I know that the more time I have, the better I can prepare for anything–expected or unexpected. In this way, I’ve taken something which gives many people a negative experience and turned it into one of my greatest strengths.

## 4) Have an appreciation for the small things

This is related to gratitude but on a micro-scale.

I’m happy for my pets the same way I am for the people I love. I’m happy that I can have a fresh cup of coffee the same way I’m happy for a home-cooked holiday meal. I feel the same level of happiness when I help a kid understand math that I feel when I learn a new skill myself.

I find happiness in all things.

Not only do all things make my life happy, but they all do so equally. I don’t say this for exaggeration, hyperbole, or poetic effect. I feel overwhelming happiness for everything in my life.

I don’t feel sad or depressed when things leave me. I simply shift my focus to something else wonderful about my life. Since I’m always building with my growth-based mindset and I’m patient enough to wait for good things to happen, I have plenty to be happy about.

If you can’t find happiness in your day-to-day activities then that’s a problem. I’ve put together a great article on [how you can fix your unhappiness](https://edlatimore.com/unhappiness) and live a more fulfilled life.

## 5) I know my values

I saved the most important for last.

I don’t value material things. This is not to say that I don’t think material things are nice to have, but they are fleeting.

They degrade, decompose, and can be destroyed. They carry no memories, but you get angry when you lose them and much violence can be traced back to people fighting over things.

I have my beef with minimalism, but one thing they absolutely get right is that stuff doesn’t equal happiness.

So what will make you happy?

It’s not that the absence of material objects will make you happy. It’s that focusing on things that endure will bring you the most fulfillment.

Experiences and relationships increase in strength and value over time. Most objects deteriorate and depreciate.

That delicious meal is more enjoyable when you share it with people you care about, regardless of its price or the ambiance of the place you dine in. At the end of the day, all you’re left with is your memories and the memories people have of you–and even then, those will eventually fade.

[I focus on experiences](https://edlatimore.com/how-to-be-a-man), good food, conversation, connection, making a difference, and my craft.

## Summary of how to keep chill

1. Show gratitude
2. Have a growth mindset
3. Be patient
4. Appreciate the small things
5. Build a value system

That list was in no particular order, but all items have one thing in common: they depend on your frame of reference and actions. When you stay focused on what you can control, you worry less about things that you can’t.

I never get angry or worried because I try to keep control over all aspects of my life. The parts I can’t control, I don’t worry about. I’m happy for everything because everything teaches me a lesson. I’m happy for everything because everything is a part of life.

The rest is up to you.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
