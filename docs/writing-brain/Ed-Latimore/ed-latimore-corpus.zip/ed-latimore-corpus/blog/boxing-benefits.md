# 8 ways boxing will transform your life

- **Source:** https://edlatimore.com/boxing-benefits
- **Date:** 2021-05-03T09:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 8876 chars

## Body (verbatim, study/swipe)

What if there was a magic pill you could take to give you more confidence, strength, [testosterone,](https://edlatimore.com/mita-nutra-man-greens-review) respect, patience, wisdom, and the ability to protect yourself?

If you hadn’t already clicked on this article to learn why you should get into boxing, you’d think I was trying to sell you snake oil.

The thing is, boxing gave me all of these things and more. It transformed my life, helped me through the depths of my alcohol addiction, and most importantly, it proved that I was capable of accomplishing anything I could put my mind to.

In this article, you’ll learn exactly what makes boxing so great, and if you’re on the fence about starting boxing, maybe it’ll help convince you to get started. If you’re already convinced then start with my post to [get into boxing the right way](https://edlatimore.com/how-to-get-into-boxing).

## 1. Boxing makes your confidence soar

Confidence is the key to getting anywhere in life. If you don’t believe in yourself, then why should anyone else? If hitting the weights makes you feel strong, wait until you know that your fists can defend you.

The difference is profound.

Lifting makes you feel strong. **Boxing makes you feel invincible.**

That confidence—the problem-solver’s kind of confidence—can’t be gained any other way than learning how to fight.

[In this guide, I’ve outlined other things you can do to develop killer confidence.](https://mind-and-fist.ck.page/4f65ddeea7)

## 2. It teaches you that pain ain’t shit

Here’s a little-known secret outside of boxing circles: **everything in boxing is painful.**

Unless a devastating knockout achieves victory, you’ll sustain quite a bit of pain even if you win.

This is because a person trained to hurt you is trying to do just that. It’s not like dealing with a hoodlum off the streets. A fighter’s punches have power behind them. But Rocky said it best:

> It ain’t about how hard you hit. It’s about how hard you can get hit and keep moving forward; how much you can take and keep moving forward. That’s how winning is done!

The training in boxing is extremely grueling and rough. You will experience tremendous pain just getting in fighting shape.

[ESPN ranked boxing the toughest sport](http://www.espn.com/espn/page2/sportSkills) to compete in, for a good reason. It’s painful to train and compete, but if you push through the pain, then the glory is all yours. If you’re unsure how to push through the pain, don’t worry I got you. Read [how to embrace pain](https://edlatimore.com/pushing-through-the-pain).

## 3. Boxing is a great way to get in shape

There’s an ongoing debate between cardio or weight training and which is best for getting in shape.

Most dudes don’t want to look like a roided-up freak show. Nor do they want to look like a skinny Kenyan marathon runner. They want to look ripped and athletic.

Boxing training is both anaerobic and aerobic.

You can burn tremendous calories by hitting the heavy bag. And if you’re wondering if [boxing can build muscle](https://totalshape.com/fitness/does-boxing-build-muscle/) and burn calories, the answer is yes. It is an effective way to build up back, shoulder, and arm muscles.

If you compete—and I recommend every man compete in a boxing match at least once—the training will turn you into a beast. To get prepared read up on [everything you need to train for a boxing match](https://edlatimore.com/boxing-training).

Getting in shape is a great reason to box

## 4. You become more disciplined than ever

It’s impossible to get good at anything without practice.

You can fool yourself about how often you run or go to the gym, but fight night tells no lies. Unless you want to suffer the pain of embarrassment, you train hard every day.

[If you can handle boxing training](https://edlatimore.com/boxing-teaches-resilience), you can become whatever you want.

Between technical training, mental concentration, toughness, and physical conditioning, there is no room for laziness or non-commitment.

The discipline you develop in boxing can be applied to anything.

## 5. You learn how to be patient

My coach always says: “Bad things happen quickly. Good things tend to take a little longer.” All progress takes time. If you want things to happen quickly, you won’t last long in training.

**Boxing weeds out people who expect quick fixes.**

An immediate test of your patience is how long it takes before a coach takes you seriously. Unless you’re a ridiculous physical specimen or rich, most boxing gyms won’t pay attention to you at first.

This is because most gyms only have one trainer. This one trainer has to train other fighters, both professional and amateur. He might even run a few regular fitness classes.

And then there’s the new guy who most likely isn’t going to stick around.

You’ll have to prove your worth and that will take time. But, if you do, it’ll be well worth the wait.

## The Mental Edge Most Fighters Ignore

Finally, there’s a supplement that improves your reaction and reduces the number of mistakes you make.

Mind Lab Pro has been proven to reduce reaction time by 12%. That’s the difference between slipping a punch, blocking it, or getting knocked out.

Mind Lab Pro also cuts anticipation errors in half. In other words, Mind Lab Pro will make it much harder for your opponent to pull of fients and distract you.

If you’re serious about your training, pick up a bottle of Mind Lab Pro.

It even comes with a 30-day, no-questions-asked, money back guaranteed.

 [Up your boxing game](https://www.mindlabpro.com/?a_aid=698b400c4a47f&a_bid=6d45f5c3)

## 6. Boxing will make you more humble

The only way to get better at this sport is to suffer.

You’ll suffer through running. You’ll suffer through sparring. Eventually, you’ll lose a fight in front of a crowd. It will be extremely embarrassing. Especially if you get knocked out.

However, if you commit to the sport, you will not only get past these difficulties but also become a better person. There’s nothing like a black eye, bloody nose, and sore ribs to build humility.

I lost my first televised professional fight, getting knocked out in the process. Talk about getting humbled.

## 7. Boxing reminds you of your own mortality

I know every time I step in the ring there’s a chance that [I come out permanently altered](https://edlatimore.com/why-i-quit-boxing), and not for the better. The toughness needed to fight also exposes you to the fragility of human life.

You learn how easy it is to damage a human being. You develop a newfound respect for people and empathy for their pain.

This is not to say that one develops a tolerance for weakness in others.

Rather, what you gain is a profound appreciation for the body’s ability to persist against difficulty.

You appreciate the mental fortitude required to continue in the face of pain.

## 8. You discover the true meaning of fear

Most importantly, you learn how to deal with it.

I once heard this phenomenon called “drowning out the noise.”

A fighter is always scared before a fight. A person is trying to hurt you. He has a good chance of doing it. If he succeeds, it will be in front of everyone.

The two biggest fears people have—dying and public humiliation—are imminent. All fighters experience this, but every weekend they act despite it.

Learning to persevere through your fears and staying committed to your goals will completely change your life in ways you never imagined. It’s a skill every man should know, and if you don’t, you need to [read this now](https://edlatimore.com/how-to-overcome-fear).

Nothing has impacted my life as boxing, and if you’re wondering whether you should start, my answer will always be yes. Start as soon as you can.

Before you know it, you’ll be on your way to becoming a version of yourself you never thought was possible.

## Optimize yourself. No Gimmicks or Hacks. Just science and care

Rebel Health Alliance is a telehealth concierge service that focuses on prevention and optimization.

By combining genetics, bloodwork, lifestyle, and medical intervention, they make you the best version of yourself. Honest, you become better than you ever thought possible.

I used them leading up to my comeback fight at 40 and will continue to use them for the second wave of my boxing career, knocking out my opponent in the first round with a body shot.

If you want to become the best version of yourself, schedule a call with Rebel Health Alliance today.

 [Schedule a call today](https://rebelhealthalliance.io/landing/health-optimization?via=edward)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
