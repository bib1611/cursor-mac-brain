# I took Gorilla Mind Smooth for 1 year—here’s what happened

- **Source:** https://edlatimore.com/gorilla-mind-smooth-review
- **Date:** 2022-01-12T13:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 15063 chars

## Body (verbatim, study/swipe)

If there’s one thing I preach, it’s knowing how to out hustle the competition. That means putting in the hard work, but also recognizing when to work smarter too. It’s why I’m a fan of taking nootropics to boost my mental focus and productivity to get more done.

For those early morning sprints when I needed some caffeine to jolt my mind into overdrive, I preferred Gorilla Mind Rush (I started using [Onnit’s Alpha Brain](https://edlatimore.com/alpha-brain-review)). Unfortunately, now that it’s discontinued, I stick to black coffee for my caffeine fix.

But for those work sessions that can’t get done until later in the day or when I’m taking a break from caffeine, [my go-to nootropic is Gorilla Mind Smooth.](https://gorillamind.com/r?id=8q1f8k)

## How it compares to Gorilla Mind Rush

Some people thought Gorilla Mind Rush was too extreme, with many users complaining of feelings of jitters and shakes.

I personally did not have any of these issues, but given them ingredient profile (it’s similar to Onnit’s Alpha Brain), I can understand the complaints because I actually find myself feeling more easily annoyed on use Alpha Brain.

I drink a lot of coffee, so might be a bit of resistance

Gorilla Mind Smooth is more low-key. Where Gorilla Mind Rush was like turning on turbo boosts of your neuroprocessing ability, Gorilla Mind Smooth is like simply using a higher grade of better burning, more efficient fuel. I almost hesitate to put Gorilla Mind Smooth into the category of nootropic. Rather, it’s a lot closer to a cognitive wellness supplement.

It’s the best stim-free nootropic I’ve used. It has been a gamechanger for when I shift my work to later in the day but don’t want to pull an all-nighter due to the caffeine.

If you’re sensitive to caffeine or looking to cycle off of it for a bit, Gorilla Mind Smooth might just be what you’re looking for.

## What to expect from Gorilla Mind Smooth

Most days, I take Gorilla Mind Smooth first thing in the morning before tackling my deep work sessions. I wake up and take it on an empty stomach so that it kicks in about 30 minutes later when I sit down to work.

Here’s what I notice after taking it, although your experience may vary:

**Within 15 minutes:** I can feel my mind start to zone in on the task at hand. I also begin to notice a slight uptick in focus and concentration. This might be placebo, many of the ingredients increase acetylcholine and that causes increased blood flow and heightened concentration. So it’s likely not in my head.

**Within 1 hour:** Every ingredient in Gorillia Mind Smooth is at peak concentration in my blood stream. It’s at this point that I generally feel in a great mood. The mood enhancement is one of the least discussed aspects of any nootropic supplement, and this one Gorilla Mind Rush is a great pick-me-up.

**After 6-8 hours:** I slowly return to my baseline state. And I mean slow. It’s a smooth transition since there’s no chance of a caffeine crash. Also, Huzeprine-A (one of the active ingredients) has a half-life of 10-14 hours. This means that it’s going to continue to have a noticable acetylcholine boosting effect hours after you take it. However, sine there are no stimulants, you never feel too anxious.

Since making Gorilla Mind Smooth a part of my morning ritual, these are the main benefits I’ve experienced.

#### [Get your mind right and pick up a bottle](https://gorillamind.com/r?id=8q1f8k)

## Benefits of taking Gorilla Mind Smooth

### Overall mood boost

This is the most surprising benefit of taking this supplement. I legitimately feel happy, more upbeat, and productive. Now granted, I’m a generally cheerful person and I don’t experience anxiety, but GMS provided a noticeable boost to my mood.

I would never describe this as euphoria. It’s more of an undeterrable optimism and higher levels of patience. This contrasts *sharply* to my experience with some other nootropics. I don’t have a temper, but I have experienced less patient on Gorilla Mind Rush or Onnit Alpha Brain. I suspect it’s due to GMS using a health dose of L-Tyrosine and Saffron Extract.

Both of these ingredients aid in the production of dopamine and seratonin. This is a very nice addition, as both of these are naturally occurring are missing in most nootropics. GMS seems to take the stance that a good mood is essential for productivity, and I’m here for it.

### Improve reaction times and athletic performance

While I’m not longer a professional fighter, I still make it a point to stay in shape. I also never miss a workout. With my routine, I’d like to think that it wouldn’t take too long to get back into fighting shape.

While I love the gym, I don’t have the same type of burning motivation I had to get in there when I was doing it for a living. That’s where GMS comes in handy, as it boosts my mood and motivation.

Since I also still spar, I noticed that GMS helps with my reaction time and explosiveness. Now to be fair, the ingredients that seem to responsible for that are pretty standard when it comes to nootropic supplements, but as far as I can tell, what makes GMS unique is that it doesn’t have any other ingredients in it that are banned by the World Anti Doping Agency (WADA).

The 100mg dose of L-Theanine helps me [maintain my reaction time and mental sharpness](https://www.sciencedirect.com/science/article/pii/S1756464611000351) to get the most out of those long grueling sessions. Couple that with the 600mg of Alpha GPC for [boosting my growth hormone and fat oxidation](https://pubmed.ncbi.nlm.nih.gov/22673596/), and it’s how I stay in peak physical form.

It doesn’t turn me into superman, it does allow me to get a bit extra out of my body. Getting just 5% more out of each workout may not seem like much in the short term, but compound those training sessions for one, two, or even five years, and your body and mind will be in an unrecognizable place from where you are now.

With that said, if you consider yourself a competitive athlete or someone looking to take their training sessions to the next level, I can’t recommend GMS enough. For a serious boost of energy and focus, take with [Gorilla Mode Pre-Workout.](https://edlatimore.com/gorilla-mode-review)

## Another hard hitting nootropic for you!

If you don’t want to take pills, Morning Would is a fantastic alternative that gives you everything Gorilla Mind Smooth does PLUS the benefits of the old Gorilla Mind Rush.

Created by a firefighter who needed peak mental performance during 24-hour shifts, this formula complements your nootropic stack perfectly, especially for morning optimization.

While Gorilla Smooth is solid, Morning Would adds crucial electrolytes and amino acids that support both cognitive and physical performance.

The Alpha GPC pairs beautifully with your Smooth stack, while the comprehensive amino blend fuels muscle growth during your workouts.. Plus, the hydration support from magnesium, sodium, and potassium keeps your brain firing at full capacity.

Whether you’re already a Gorilla Smooth user or looking to expand your nootropic arsenal, I highly recommend trying out Morning Would. It tastes great and makes you feel even better.

 [Up your mental game here](https://www.zenithsupplements.us/ed-latimore)

## Drawbacks

### Subtle effects

GMS is not only stimulant free, but the main difference between GMS and Gorilla Mind Rush is that GMS lacks the ingredient DMAE (a potent acetylcholine booster) and 2-aminoisoheptane, a potent stimulant that is considered a synthetic version of the banned ephedra. As a result, this supplement is noticeably less intense than GMR.

The banned 2-aminoisoheptane in the old Gorilla Mind Rush

If you’re a harder stimulant or nootropic veteran, you may simply not feel any effects from it. I find this to be particularly true when I’ve been drinking a lot of coffee since caffeine is such a powerful stimulant.

This isn’t necessarily a bad thing if you’re looking for something a little on the lighter side for your system. I wouldn’t take this before a chess match if I was looking for an edge, but I WOULD take it to keep my mood high while I’m playing.

If you’re expecting GMS to make you feel like Bradley Cooper in *Limitless*, this ain’t it. The effects are much more subtle. Compared to other stimulant-laden nootropics, it can sometimes be hard to tell if I’m experiencing a mental boost or just the results of a placebo. It’s when I’ve refrained from taking stimulants for a while that I notice the full effects of GMS.

#### [If you can deal with not being hyperstimulated but focused, grab a bottle.](https://gorillamind.com/r?id=8q1f8k)

## Ingredients

A big reason why I’m a proponent of the Gorilla Mind product line is that they’re very transparent about what goes into their products, which can’t be said about other popular nootropic blends. And since I’m strict about what I put in my body, I only take what I recognize and know is healthy for me.

Here’s the list of ingredients for Gorilla Mind Smooth:

I’ve also included a short explanation of what each ingredient does—though I encourage you to do your research. [Examine](https://examine.com/) is a trusted resource for learning more about each ingredient.

- **L-Tyrosine:** An amino acid that [reduces stress, boosts memory, and improves endurance](https://pubmed.ncbi.nlm.nih.gov/10230711/)
- **Alpha GPC:** A choline-containing supplement that boosts information recollection/absorption, focus, concentration, HGH levels, memory, and physical performance
- **Kanna:** A South African herb that [reduces anxiety, increases cognition, and improves reaction time](https://pubmed.ncbi.nlm.nih.gov/23903032/)
- **Ginkgo Extract:** A Chinese herb that [boosts cognitive function](https://pubmed.ncbi.nlm.nih.gov/10890330/)
- **Bacopa Monnieri:** A nootropic herb that shields brain neurons from damage, produces mild euphoria, reduces anxiety, joint/muscle pain, increases memory retention, well-being, mental energy, and information recollection/absorption
- **L-Theanine:** An amino acid that reduces anxiety and stress; promotes relaxation; improves sleep quality
- **Huperzine A:** A cognitive enhancer that increases cognitive function and memory, helps body composition, and combats aging
- **Saffron Extract:** Spice with antidepressant properties

## How it compares to other nootropics

Nootropics have been in the spotlight for a few years now. It seems like almost every sports nutrition store and supplement brand carries some type of proprietary nootropic blend. But as you well know, not all supplement brands are created equal.

Here’s how GMS stacks up to some of the most popular nootropics out there.

### Vs. Alpha Brain

Onnit’s Alpha Brain may be the most popular nootropic on the market, thanks in large part to the incredible marketing efforts of their team and Joe Rogan. But being the most popular doesn’t always equate to being the best.

The most disappointing finding with Alpha Brain is that it lumps some of its most beneficial ingredients into proprietary blends. Unlike Gorilla Mind Smooth, you have no way of knowing how much L-Theanine or Alpha-GPC you’re getting from each recommended serving.

Typically when manufacturers advertise proprietary blends, they’re trying to hide behind a poor formula or cover up the fact that they’ve copied someone else. Either way, a lack of transparency isn’t something I look for in my supplements.

With that said, whatever they’re mixing in Alpha Brain is effective. [I’ve used it and written about it.](https://edlatimore.com/alpha-brain-review) They’re just not transparent about it.

### Vs. Qualia Mind

Another nootropic that has gained popularity is Neurohacker Collective’s Qualia Mind. While they do a much better job listing out the dosage of each ingredient—and there’s a lot of them—it’s the price tag that’s hard to swallow.

At $139 per 154-capsule bottle, Qualia Mind comes out to $6.30 per their recommended daily serving of 7 capsules. Compare that to Gorilla Mind Smooth’s $39 price tag for a 90-capsule bottle, and you’re paying just $1.30 per daily serving.

I consider both brands to be high quality, but it’s hard to justify paying almost five times as much per serving for the same cognitive benefits. Feel free to experiment with both, but GMS has my vote for the best bang for your buck.

#### [Get smarter, work better, spend less money. No brainer to get a bottle.](https://gorillamind.com/r?id=8q1f8k)

## Frequently asked questions

Before I try any new supplement or product, I always do my research to ensure it makes sense to take. With that said, here are some common questions I get about GMS so you can make your own decisions about whether or not it’s right for you.

Can I take it at night before bed?

Yes, because it’s stimulant-free, it won’t affect your ability to fall asleep. In fact, Huperzine-A is often taken to induced lucid dreaming because it emabbles the brain to hit a theta brain wave state while sleeping ([Source](https://luciddreaming.blog/huperzine-a-lucid-dreaming/)).

  Can I take it as a pre-workout supplement?

I prefer taking it for cognitively demanding tasks like writing and studying chess, but GMS can be used as a pre-workout for when you need [improved mental performance through the effects of acetylcholine](https://pubmed.ncbi.nlm.nih.gov/22071706/). I sometimes take it before long training sessions to keep my mind sharp and laser-focused.

  Can I stack it with other supplements?

Since GMS is stim-free while improving concentration and endurance, you can stack it with pre-workout supplements like [Gorilla Mode](https://gorillamind.com/products/gorilla-mode?rfsn=4525775.fe5747) to boost your strength output at the gym. But use as directed and do your research before combining with additional caffeine or dietary supplements.

  Are there any side effects?

No side effects. It’s also non-habit forming and doesn’t make you feel jittery or anxious. It just makes it easier to stay on task and ignore any distractions. It’s the main reason why I recommend it.

## Conclusion

Gorilla Mind Smooth has become my go-to nootropic for when I need to knock out hours of deep, focused work—no matter the time of day. It’s the best nootropic I’ve used for achieving heightened levels of focus without the jitters and pretty much the only supplement I take aside from my workout supplements and black coffee.

If you found my review helpful, I’d love for you to use my link, get [Gorilla Mind Smooth here](https://gorillamind.com/r?id=i70is2). (I get a small % cut of each sale made through the link, which helps cover site costs.

I look forward to hearing your thoughts, reviews, and feedback. And if you’re already using GMS, let me know how it’s helping you.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
