# How to increase willpower (the easiest way to break bad habits)

- **Source:** https://edlatimore.com/how-to-increase-willpower
- **Date:** 2021-10-11T13:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 10443 chars

## Body (verbatim, study/swipe)

> Willpower is the key to success. Successful people strive no matter what they feel by applying their will to overcome apathy, doubt or fear. — *Dan Millman*

Everyone wants more out of life: [more money, more muscles, more mating](https://edlatimore.com/how-to-be-a-man). But few people summon the strength to make a dent in their reality. This discrepancy isn’t usually due to a lack of intelligence or a series of bad luck, but rather, a lack of willpower.

Willpower is the ability to do what needs to be done to get where you want to go, even if it’s hard and you don’t want to follow through. The difficulty of a task is irrelevant in direct relation to the personal importance of that task’s outcome.

You need to take action and make hard decisions that align with your short-term and long-term goals. And you need to be able to do it daily, regardless of any difficult feelings or distractions that come up along the way. Impulsive individuals who cannot control their actions get nowhere.

Unfortunately, there are an infinite number of short-term temptations in today’s world that can derail our true desires. Without willpower, it’s easy to stop striving and settle for the comforts of modern life. When things get hard and our goals don’t immediately transpire, things like marijuana, alcohol, free internet porn, and fast food all act as comforting alternatives that pacify our dissatisfaction in the moment.

But you’ve already been down that road, and you know it leads to a dead end. This article will show you how to increase willpower fast so you can begin to make things happen in your life.

## Know your goals

The famous Marshmallow experiment by Walter Mischel at Stanford University measured the effects of [willpower as a predictor of future success](https://edlatimore.com/high-value-man) by giving kids one marshmallow immediately or two if they waited 15 minutes. The researchers then followed the children into adulthood and found that those who delayed gratification and exercised willpower in the study grew up to be more successful in all areas of life.[1](#fn:1)

Whether trying to overcome procrastination or temptation, it needs to be obvious what your willpower earns you and what a lack of it will cost you. \*\*If you don’t clearly know what you want, you won’t be willing to make the sacrifices necessary to attain it. \*\*

I quit my alcohol and pornography habits because I wanted:

- More money
- My own business
- To escape the ghetto
- A fulfilling relationship

Sure the process was difficult at times, but the outcomes were non-negotiable. Once I cemented my commitments, it was just a matter of showing up and finding a way through.

As Jim Rohn once said: “When the promise is clear, the price gets easy.” In other words, make sure you know the ‘why’ before you worry about any ‘how’.

## Avoid overwhelm and start small

Trying to do too much at once is the best way to make sure nothing gets done at all. According to a study done by Roy Baumeister at the American Psychological Association, willpower, like a muscle, wears out with repeated use.[2](#fn:2) This means that **the more we use our willpower on non-essential tasks, the less we will have for the moments that count.**

I remember at one point in my life, I was getting a physics degree, boxing at a professional level, working part time in the army, starting a relationship, and trying to build my presence online. As you can imagine, I didn’t excel in any one area.

I even failed a few math classes and had to retake them multiple times because my energy was split in so many directions. (If you struggle with math, check out this article: [8 unexpected reasons why math is so hard](https://edlatimore.com/why-is-math-so-hard).) A few years later, I graduated college and dropped everything except my relationship and business efforts. I soon saw exponential growth in the few areas that mattered.

**Only a select few activities will move the needle in your life.** Typically speaking, there are one or two good habits that will make everything else easier and only one or two bad habits that you need to get under control. If you try to become superman and develop every good habit in the self-development archive while simultaneously trying to become a saint, you’re bound to fail.

**Get clear on your dominant goals and then decide what few good habits are most important and what bad habits sabotage your efforts.** For the time being, don’t waste your willpower anywhere else. An effective method you can use for prioritizing in this way is the Eisenhower Matrix which you can see below:

## Build willpower by reducing stress levels

> The biology of stress and the biology of willpower are simply incompatible. The fight-or-flight response [floods the body with energy](https://edlatimore.com/mita-nutra-man-greens-review) to act instinctively and steals it from the areas of the brain needed for wise decision-making. — *Kelly McGonigal*

The part of our brain that controls willpower is the prefrontal cortex. Research shows that when we experience stress, the prefrontal cortex becomes overpowered by the amygdala.[3](#fn:3)

The amygdala is the oldest part of our brain and is primarily responsible for surviving short term threats rather than helping us achieve our long term goals. After all, long term goals don’t matter much if you don’t live to enjoy them.

Therefore, to build willpower, you need to keep stress to a minimum.

Three fundamental methods to reduce stress include:

- Physical activity
- Meditation
- Quality sleep

I’ve written about physical exercise on my website, so you can check out the following article if you’re interested:

[8 reasons to push through the pain](https://edlatimore.com/pushing-through-the-pain)

However, I haven’t written a lot about meditation or sleep, so let’s take a quick look at how they can help us build willpower…

### Practice meditation

Meditation can help reduce stress hormones and quiet the amygdala, helping us make better decisions focused on the long term rather than the survival-based present moment.

Meditation also helps build self-awareness. When we take time to slow down, we can better organize our priorities and think of the big picture. We can also objectively assess what is worth stressing over and what we can safely ignore. It’s almost like closing all the non-essential tabs on your computer.

I don’t claim to be an expert on meditation, so I recommend reading this article for tips on how to [get started with meditation](https://www.pickthebrain.com/the-science-of-self-control-can-you-increase-your-willpower/) to build willpower.

### Get enough sleep

If you’ve ever had a night of fewer than six hours of sleep, you understand the willpower depletion that follows. In my experience, nothing can destroy my self-discipline in my diet, exercise routine, and work output all at the same time like a lack of sleep can.

According to a 2009 article by Kelly McGonigal Ph.D, “Disrupted sleep leads to a decline in physical health and cognitive functions, causing learning disabilities and an increase in impulsive behavior.”[4](#fn:4)

Additionally, a 2015 study, *Interactions between sleep habits and self-control* by Frontiers in Human Neuroscience, shared the following:

“A sleep-deprived individual who has expended the necessary resources for self-control is at an increased risk for succumbing to impulsive desires, poor attentional capacity, and compromised decision making.”[5](#fn:5)

Make sure you get enough sleep. An extra 30 minutes every night can massively build willpower reserves.

## Increase willpower with accountability

In early 2020, I started running a community for men who wanted to stop using porn called the Dick Detox challenge. I saw guys who—by their own words—couldn’t go two days without porn, achieving over 100 days without it.

I asked roughly 20 successful members what was most helpful in quitting. All but one participant said that group accountability was the most essential factor in their success.

[Accountability allows you to set goals](https://edlatimore.com/how-to-be-a-man) when your willpower is high and ensures that you can’t step back the second your initial excitement wears off. Accountability gives you a chance to succeed by calling on the strength of others rather than relying on the brute force of your willpower.

When you give up a bad habit or start towards an important goal, involve as many people as possible in your decision. They will give you extra pressure, support, and wisdom to strengthen your resolve.

## In summary

Increasing your willpower will make the process of achieving your goals significantly easier by helping you form new habits while overcoming any lingering bad habits.

Here’s a quick recap of the tips we discussed to build willpower:

- Get clear on your goals
- Focus only on what moves the needle
- Reduce stress
- Practice meditation
- Get enough sleep
- Find a friend or group to hold you accountable

The rest is up to you.

---

### References

1. Mischel, W., & Ebbesen, E. B. (1970). [Attention in delay of gratification](https://content.apa.org/doi/10.1037/h0029815). *Journal of Personality and Social Psychology, 16*(2), 329–337. [↩](#fnref:1)
2. Muraven, M., & Baumeister, R. F. (2000). [Self-regulation and depletion of limited resources: Does self-control resemble a muscle?](https://psycnet.apa.org/doi/10.1037/0033-2909.126.2.247) *Psychological Bulletin, 126*(2), 247–259. [↩](#fnref:2)
3. Harvard Health (2020). [Understanding the stress response](https://www.health.harvard.edu/staying-healthy/understanding-the-stress-response). \_Harvard Health Publishing \_ [↩](#fnref:3)
4. Kelly McGonigal Ph.D. (2009). [In defense of a good night’s sleep](https://www.psychologytoday.com/us/blog/the-science-willpower/200910/in-defense-good-nights-sleep). *Psychology Today* [↩](#fnref:4)
5. June J. Pilcher, Drew M. Morris, Janet Donnelly, and Hayley B. Feigl (2015). [Interactions between sleep habits and self-contro](https://www.frontiersin.org/articles/10.3389/fnhum.2015.00284/full)l. Frontiers in Human Neuroscience, PMC4426706. [↩](#fnref:5)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
