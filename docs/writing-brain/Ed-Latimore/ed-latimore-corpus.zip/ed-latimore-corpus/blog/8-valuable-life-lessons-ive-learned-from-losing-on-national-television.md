# 8 lessons from losing a fight

- **Source:** https://edlatimore.com/8-valuable-life-lessons-ive-learned-from-losing-on-national-television
- **Date:** 2016-10-01T10:36:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 9232 chars

## Body (verbatim, study/swipe)

Many of you witnessed my obnoxious posting about my fight on Showtime last weekend ***(Edit: The exact day of the fight was September 23rd, 2016)***

I’m hoping you had something better to do than watch. Either way, I’ll fill you in. This was my first fight on television, and I got stopped in the 1st round.

Someone is likely to get knocked out whenever you have [two men over 200 lbs in a boxing ring](https://edlatimore.com/boxing-training). It doesn’t matter how sharp your footwork is or how much sparring you had in preparation for the fight. Your fists are wrapped liked a cast and placed into boxing gloves designed to multiply and transmit your force.

My opponent (quite the affable fellow outside the ring) landed a tremendous short right over my jab, and the fight was a short night after that. I tried to fight back, but I couldn’t recover from the knockdown in enough time to beat the referee’s count.

Losing fights happens to almost every fighter. When fighters think about fight night, and they let themselves think about the possibility of losing in any of the striking arts (boxing, MMA, or kickboxing), a first-round knockout is the worst-case scenario.

It’s a terrible way to lose, and it was live for the whole world to see. My opponent was simply that better fighter that night. It wasn’t even a close fight.

Yeah, it’s awful, but it’s part of life. I move on, and I become better from it. Above boxing, my primary purpose in life is to take what I experience the hard way and break it down so that people may learn from it the easy way.

I’ve spent the last week piecing together notes on my reaction to this event.

In many ways, I’ve learned more from this in 3 minutes (technically speaking, the referee called a stop to the contest sometime after the 2-minute mark) than I did from the rest of my [9-year career in boxing](https://edlatimore.com/how-to-get-into-boxing). Life is funny this way.

If you can look at things the right way, you learn more from failure than success. It was the great Jay-Z who said:

> I will not lose for even in defeat, there’s a valuable lesson learned so that evens it up for me.

Here are 8 valuable lessons I learned from losing on national television.

## Embarrassment is the worst emotion to feel

It’s miserable because there is no way to confront or conquer it.

[You can face your fears.](https://edlatimore.com/how-to-overcome-fear) You can do something to cheer yourself up if you are experiencing sadness.

But embarrassment is just a burden you must bear until it heals. Your self-worth takes a hit, and there’s nothing you can do but let it pass.

The one fortunate thing about embarrassment is that, like all other negative emotions, it is highly susceptible to the [power of gratitude](https://edlatimore.com/6-reasons-to-be-grateful).

## The people who truly love you do so because of who you are

Our worst fear is that people only care for us because of what we do.

People who only associate with you because of your accomplishments can only like you. At best, they can respect you.

These are fine emotions to elicit, but we secretly fear that those closest to us are there because of a deeper agenda.

Some people are. There’s nothing you do about that. But in times of distress, the people who love you will be there for you. Though this should be expected, it comes as a most welcome surprise.

## You are never as good as they say you are when you win, and never as bad as they say you are when you lose

It’s impossible to accurately assess your level immediately after you lose, but it is important to figure out where you stand.

[You must evaluate yourself](https://edlatimore.com/high-value-man) and decide whether you merely made a mistake, a different course to the same goal is required, or if it’s time to abandon the course altogether.

Everyone’s path is different, but it’s impossible to know that while you still suffer the emotional effects of the loss.

***(Read: “***[***48 Ed Latimore Boxing Quotes***](https://edlatimore.com/boxing-quotes-from-ed-latimore)***”)***

## Heaven and Hell represent what happens when you die

If you’ve led a good life helping others, you go to heaven. If you’ve led an evil life and taken from others, then you go to hell.

The same can be said of you when your ego dies.

[Few men’s egos can survive losing on television by a TKO.](https://edlatimore.com/boxing-benefits)

If you’ve been an asshole before your loss, hell awaits you in the world and on social media. If you’ve done your best to uplift and help those around you, the outpouring of support from the world and on social media will be immense.

This is often stated in another, less esoteric way: How you treat people on the way up determines how they will treat you on your way down.

## The Mental Edge Most Fighters Ignore

Finally, there’s a supplement that improves your reaction and reduces the number of mistakes you make.

Mind Lab Pro has been proven to reduce reaction time by 12%. That’s the difference between slipping a punch, blocking it, or getting knocked out.

Mind Lab Pro also cuts anticipation errors in half. In other words, Mind Lab Pro will make it much harder for your opponent to pull of fients and distract you.

If you’re serious about your training, pick up a bottle of Mind Lab Pro.

It even comes with a 30-day, no-questions-asked, money back guaranteed.

 [Up your boxing game](https://www.mindlabpro.com/?a_aid=698b400c4a47f&a_bid=6d45f5c3)

## Perspective is everything

The morning after the fight, I moped around and felt very bad for myself.

Depressed isn’t quite the feeling I experienced, but I was definitely caught up in my self-pity.

Then I sat down for breakfast in the hotel, and the news was running a segment on the [bombings in Aleppo, Syria](https://en.wikipedia.org/wiki/Aleppo_bombings_(April%E2%80%93July_2016)). Then it followed up with [police shootings in Tulsa, Oklahoma and Charlotte, North Carolina.](https://www.cnn.com/2016/09/22/us/tulsa-charlotte-shooting-protests/index.html) Finally, I learned that [a guy walked into a mall in Washington State and killed five people](https://en.wikipedia.org/wiki/Cascade_Mall_shooting), one of which was a 16-year old cancer survivor.

Suddenly everything was put into perspective.

There are REAL problems in the world. I took an embarrassing loss on television, which sucks for me, but there are people in the world dealing with the loss of life and liberty for no reason other than they were in the wrong place at the wrong time.

At that point, my mood jumped three levels because I remembered something Randy Couture once told me: “If the worst thing that happens to you in your life is that you lose a fight, then you’re doing alright.”

Me with Randy Couture after he gave me that life-changing advice.

## The more unique your experience in life, the fewer people there are that can relate to it.

This means that not only are there fewer people who can give you advice, but there are fewer people who you can talk to about your specific problem.

The people who love you try to understand and give you words of encouragement, but in the end, you still feel alone and misunderstood. However, this is another clever ego trap.

As long as you view yourself as different and superior, you are blocking the energy people offer you out of their love for you and the kindness in their hearts.

## Identity is a tricky thing

The hardest part of a setback is that it forces you to reconsider elements of your personality that you have defined yourself by for years.

One must know thyself thoroughly, for this is the only way to form your identity fully. It’s very easy to see yourself through the lens of one accomplishment or one feat.

The reality is that there is far more to a person than that.

I suspect that people take on [self-destructive behavior](https://edlatimore.com/lessons-from-the-ghetto-willingness-to-fight) after a professional setback because they have come to define themselves only by their accomplishments.

Failure ceases to be a learning opportunity for these people and instead becomes the stake at which they burn themselves. This is another ego trick you must be vigilant against, for your connection with people is the most important thing.

The strongest prophylaxis against this is remembering your relationships with others and the other ways you bring value to the world. Also, don’t forget that the world will go on spinning with or without your precious identity intact.

## What you’re afraid of is worse in your imagination than in reality

I used to be scared of losing or getting knocked out in front of people. Now I know that it’s not so bad.

The world goes on.

I’m not dead and the important things in my life are still there.

This is how it is with most of the terrible things you fear. It is either highly unlikely that they will happen or what your imagination makes them is far worse than reality.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
