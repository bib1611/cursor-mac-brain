# How to Be More Attractive as a Man (Science-Based Guide That Actually Works)

- **Source:** https://edlatimore.com/how-to-be-an-attractive-man
- **Date:** 2020-12-21T04:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 35481 chars

## Body (verbatim, study/swipe)

How to Be More Attractive as a Man (Quick Answer)

To become more attractive as a man, focus on four key areas:

- Physical appearance (fitness, grooming, hygiene)
- Style (fit, simplicity, and consistency)
- Personality (confidence, humor, assertiveness)
- Social status (ambition, competence, and direction)

Improving these four areas consistently will make you noticeably more attractive within 3–6 months.

A lot of guys spend most of their lives with no clue how women think.

Between the lack of strong father figures…

The misinformation being spread by schools and mainstream media (see: “toxic masculinity”)…

Hollywood movie tropes (do nice guys finish first or last, again?)…

And not to mention the things girls *say* they like…

It’s hard to figure out what exactly makes a guy more attractive. To separate truth from fiction. I don’t know everything about the fair sex, but I *did* amass a wealth of experience during my adult life.

Combined with a healthy dose of common sense (and some peer-reviewed studies), this article contains most everything of what I’ve learned about women, dating, and sexual and romantic attraction.

Me and my girlfriend of over nine years

### What this article won’t do for you

With that said, this is not so much a dating as *an anti-dating guide*. I won’t tell you what this or that body language means, or give you any clever lines to get more dates on Tinder. Instead of chasing tail, I want you to focus on yourself. I want you to get the fundamentals right, to make yourself more attractive in the eyes of women.

I also won’t teach you the in-depth evolutionary reasons for why women find certain things attractive (but I will be referencing material like that, in case you’re interested).

**This article is an action-oriented and comprehensive guide to raise your status in the dating market.**

## The 4 Traits That Make a Man Attractive

There are four major factors that contribute to male attractiveness (or lack thereof):

### 1. Physical appearance

Women care about looks, but not as much as men do. Get physically fit (achievable within 6 months unless you’re severely obese or extremely skinny), choose a basic but clean haircut, maintain a short stubble, get a basic skincare routine, avoid body odor, and [wear cologne](https://pubmed.ncbi.nlm.nih.gov/19134127/).

### 2. Style

Your fashion style is very important, because it affects your perceived body shape, signals social status, and shows that you have your life put together. Wear basic, timeless pieces of high quality—and always make sure your clothes are fitted.

### 3. Personality

Women find charismatic, somewhat extroverted, self-confident men attractive. Be assertive, have a sense of humor, and don’t be shy. More about this later. Cultivate hobbies that make you a more interesting, well-rounded person.

### 4. Social status

Most women aren’t gold diggers, but women do care about social status and wealth to a much greater extent than men do. Make sure you’ve got your shit put together. Be ambitious, work hard, and apply yourself.

These are the birds-eye view recommendations for each major pillar. I will go into far more detail—and make concrete, actionable recommendations that will get you noticeable results in 3-6 months.

How Long Does It Take to Become More Attractive?

Most men can dramatically improve their attractiveness in 3–6 months by:

- lifting weights consistently
- improving grooming
- upgrading wardrobe basics

## How to Be More Physically Attractive as a Man

Do women care about looks? Yes. But they care about it far less than guys do, and no matter the genes you were born with there are plenty of ways you can make yourself more physically attractive to girls.

Some guys think they’re not good-looking or handsome enough to attract hot girls. Let me dispel that fiction right now. Unless you have Quasimodo-like deformities, not being blessed with top 10% genetics is not an excuse for failure.

Mad Men actress Christina Hendricks is considered one of the most attractive women in the world. She’s married to Geoffrey Arend, who definitely doesn’t have a chiseled jawline or model looks.

Women care less about looks than men do, and to the extent that they do care, they look for different things.

As a man, your physical appearance is judged in three different categories:

- Grooming
- Physique/fitness
- Face
- Height

There’s not much you can do about your height or the way your face looks (apart from keeping it clean), so I won’t go into much detail about what facial features women like. It might be useful for you to know that [girls prefer guys whose facial features are neither too feminine nor too masculine](https://onlinelibrary.wiley.com/doi/full/10.1111/jeb.12958).

For the other factors: grooming and fitness, there’s plenty you can do to increase your attractiveness to women.

## Become more attractive without turning into a d-bag

 [Get the short free guide here](https://mind-and-fist.ck.page/ae776819a8)

### Haircut advice

Grooming is simple for guys. Unlike most women, you don’t have to spend an hour every day putting on or taking off make-up in order to look good.

There’s no universal “optimal hairstyle” for men. The haircut that’s right for you is going to depend on the shape of your face, as well as what your personal style is.

The principles are universal, however: your haircut should look clean. 99% of guys are best off going for a basic style. Think undercut, crewcut, classic taper, or a quiff. Make sure you learn [how to talk to your hairdresser](https://www.artofmanliness.com/articles/get-the-perfect-haircut-how-to-talk-to-your-barber/). He or she can help you determine what style would best suit your face.

Only shave your head if you’re black or if you’re balding. If you are balding and have money, consider a hair transplant. I got one and it gave me a huge self-confidence boost. If you’re interested in learning more about the hair transplant process and my experience with it, read my article about [getting an FUE hair transplant](https://edlatimore.com/my-personal-experience-getting-an-fue-hair-transplant).

If an FUE transplant is too expensive, consider using:

- [Topical finasteride+Minoxidil Spray](https://edlatimore.com/topical-finasteride-and-minoxidil-spray)
- [Hairmetto Topical Saw Palmetto](https://edlatimore.com/hairmetto-topical-saw-palmetto)
- [Derma Rolling](https://edlatimore.com/derma-roller-for-hair)
- [Low-level laser therapy](https://edlatimore.com/how-to-prevent-hair-loss)

All of these work pretty well to regrow your hair, but you have to catch it early (read my early hair loss prevention guide). If you’re already too far gone, you may as well shave your head.

### Clean-shaven, light stubble, heavy stubble, or full beard?

Facial hair is a signifier of age and social dominance. It can age you up or down and make you look more dominant or less dominant.

In my personal experience, full beards are polarizing. Some women like them, some don’t. Research published in the Journal of Evolutionary Biology suggests that [full beards are most attractive to women looking for long-term relationships](https://onlinelibrary.wiley.com/doi/full/10.1111/jeb.12958). With that said, not everyone can pull off a full beard.

If you have trouble getting hair bumps but still want a clean-shaven look, then an electric razor is your best bet. I’m a black guy who gets hair bumps BAD, so when I enlisted in the ARMY and was forced to shave daily with a regular disposable or cartridge razor, my face quickly got bad.

This is when I discovered that an electric razor does an excellent job of getting a shave close enough to pass inspection without being so close that I got hair bumps. As an added bonus, you can adjust how close you want to shave if you want to rock the five o’clock shadow look. Bread trimmers also work excellently. My suggestions here all come from being a black dude who gets hair bumps, which means they will for everyone else.

If you do grow a beard, make sure that it’s well-maintained. A messy beard will make you look like you’re homeless. **Most guys will look best with a well-maintained stubble or completely clean-shaven.**

### Physical fitness and the ideal male body type

There are a lot of lies and misinformation about what the ideal male body looks like. I’m sure you remember the “dad bod” craze of 2015. Women frequently tell their male partners that they don’t care about muscles.

They’re lying.

According to research on bodily attractiveness, [**women consistently and overwhelmingly prefer the bodies of more muscular men**](https://royalsocietypublishing.org/doi/10.1098/rspb.2017.1819). Specifically, what matters is cues of upper body strength. Whether you’re overweight or ripped is irrelevant, according to the research—as long as you have a powerful frame.

These are both viable and attractive body types for men

But, other things being equal, a leaner physique will look stronger than a fatter physique. So if you want to make your body more attractive, you need to focus on two things:

- Building muscle mass
- Reducing body fat

To accomplish these things, hit heavy weights and eat healthy food. [Intermittent fasting](https://www.foreveralphablog.co.uk/intermittent-fasting/2020/04/intermittent-fasting-guide/) is also great for fat loss (and it builds self-discipline).

You *should* be doing more to take care of your body for its own sake. What I’m outlining here is just the fastest way to make yourself more attractive.

In terms of weight, there’s no “ideal weight” you should aim for. Instead, look at BMI and body fat percentage:

- [Get your body fat to somewhere around 10-14%](https://gumroad.com/a/431682675/SfiYj)
- Get your BMI to around 23-27

If you’re 5’10”, you’ll look best at about 11% body fat and weighing 175 to 190 pounds. That’s not freakishly huge. And you shouldn’t aim to be.

I know this may seem to contradict the research I cited earlier. But here’s the thing: the women in that study were strictly asked to rate the **bodily attractiveness** of different male bodies: aesthetically, women prefer more muscles. But there’s more to attraction than aesthetics. **Women almost always go for guys who look like soccer players or swimmers, not Olympic weightlifters.**

It doesn’t take long to get close to your ideal metrics. Unless you’re severely obese or ultra-skinny, you can do it in 6 months of healthy eating and regular weightlifting. You might not be as ripped as you’d like to be, but your shape will be close to ideal.

Side note on weightlifting: Consistency always trumps everything else. It’s better to hit the gym two times a week for 6 months, than it is to hit it every day and drop off completely after two or three weeks. You’re running a marathon, not a sprint.

Do Looks Matter for Men?

Yes—but not as much as most men think.

Women care more about:

- confidence
- status
- presence

Looks matter, but they are only one piece of the equation.

First of all, let’s get this straight: Caring about how you look and the clothes you wear is not gay.

You don’t need to stay up to date on all the latest fashion trends. In fact, unless you’re genuinely interested in that (in which case more power to you) it’s probably best to ignore fashion trends altogether.

But if you respect yourself and want others to do the same—especially women—you need to master at least the basics of menswear and style.

Buck the trends and stick to principles and clothes that will never go out of fashion. The 80/20 rule applies here as well. 20% of your effort produces 80% of your results.

In most cases, what makes an outfit attractive is *proportion and scale*. **To make yourself more attractive, wear fitted clothes with small or no patterns, wear mid- or high-rise pants, and choose the right colors.** That is the big-picture recommendation. Remember it and follow it.

On the left: 2012, wearing an untucked, baggy dress shirt with washed-out jeans that are also too baggy. On the right: 2020, wearing a fitted polo shirt, tailored khakis and monk straps—all in a color combination that compliments my dark skin.

Dressing well is important for two reasons:

1. It will make you more attractive to women in and of itself
2. It will give your self-confidence a boost, which in turn will also make you more attractive to women

### How your clothes should fit you

By far the most important aspect of men’s style is *fit*. If your clothes don’t fit you, it won’t matter if you’re wearing Walmart or Hugo Boss: you’ll look goofy either way.

The clothes you wear should feel “tailored” to your body. They shouldn’t be baggy, nor should they cling to your body (unless you’re extremely athletic).

Below are two quick rules of thumb to keep in mind when trying on clothes.

### How should a t-shirt or polo shirt fit?

Your sleeves should end at the middle of your biceps, and you should be able to fit no more than two fingers inside them without stretching the fabric. You should be able to pinch (not pull) 1-2 inches of fabric on each side of your torso. It should end mid-crotch.

The goal of a man’s shirt is to show off the work he’s put in. I find that a good-fitting V-neck or high-quality polo will do a great job in the summer.

- Good fitting, easily affordable v-neck shirts
- Turtlenecks that stretch and form to your body for good winter fashion

In the winter, go for anything that fits and shapes your body.

This will largely come down to the fabric. Wool, cotton, and cashmere are great fabrics. Especially if they’ve got a touch of Lycra or micro fabric to help it stretch

***Tappered Menswear is the brand I’ve recently started wearing. They have an assortment of v-necks and polo shirts that look great. Especially if you’ve been hitting the gym.***

[***Check them out here!***](https://taperedmenswear.com?ref=12)

### How should pants fit?

Your pants should fit snugly around your waist with no need for a belt to hold them up, and they should gently hug your butt. They should be slim around your legs, without clinging to them: you should be able to pinch 1 inch of fabric on both sides of your thigh. Your pants should not bunch up around your shoes: if they do, they’re too long.

- Slimfit jeans for men
- Slimfit khakis for men

### Wear clothes that make you look taller and leaner

Unless you’re 6’8” or above, you should pick outfits that make you look taller and leaner. Brock from The Modest Man, a blog and YouTube channel that specializes in men’s style for guys that are on the shorter side, has a great video guide on things to do and not to do:

If you’re on the taller side (i.e. 6’8” or above), you might want to make yourself look a little shorter by doing the opposite of what Brock recommends in the video: wear pants and shirts that contrast each other strongly or wear bigger patterns.

You’re stuck with your genetics. When it comes to height, there are basically 3 types of men: <6’1”, 6’0”-5’10”, 5’9”>.

If you’re in the first group, your life is good. If you’re in the last group, there isn’t much you can do. Unless you have money for surgery to make yourself tall.

The middle group is the group that will benefit tremendously from shoes and insols that will add 2-3” of height. In the winter, this is easy because boots naturally add height. For the rest of the year, or for guys who live somewhere without a cold winter, these shoes will allow you to discretely add height.

The leader in shoes that make you taller for all sizes is [Conzuri](https://www.conzuri.com/). You discretely and easily add up to 2.5 inches to your height. That is significant enough for any man to change his dating prospects and business opporturnities.

- Use discount code “EDWARD25477” to 15% off your order.

#### [Get Conzuri shoes to become taller here](https://www.conzuri.com/)

### What clothes to wear

Every man has a slightly different style. The specific items that I wear are not necessarily the same type of items that you want to wear.

If you’re lost when it comes to what clothes to wear, I recommend Tanner Guzy’s excellent course, *Dress Like a Man*.

It will equip you with the knowledge and skills you need to assemble a killer wardrobe: the science of style, the 35 staples you should have in your closet, “style as storytelling” (i.e. how to use style to communicate your own identity).

As a general rule, a good, manly wardrobe should consist of high-quality, properly sized basics: t-shirts, polo shirts, crewneck sweaters, button-down shirts, chinos, and at least one or two full suits (navy or charcoal for 99% of occasions and black for funerals).

If you can afford it, it’s better to pay more for high-quality products—they fit, feel, and look better (and you save money in the long run because they last longer).

Muscular and lean guys can show off their bodies with athletic-fit clothes from State and Liberty.

If you’ve got an athletic build like me, I recommend [Tapered Menswear](https://taperedmenswear.com?ref=12).

### Style dont’s

Aside from the fit, always pay attention to these things:

- Unless you’re 13, don’t wear novelty/graphic tees outside the gym
- Don’t wear wrinkly clothes
- Make sure your clothes don’t smell bad—body odor kills attraction

## Hobbies to meet women

You don’t need to go to bars or clubs to meet women. In fact, for those of you who are looking for serious girlfriends, those are the last places you should look.

Hobbies are a great way to meet women. Not only that, every man *needs* a skill or hobby. It gives you confidence and makes you more interesting to be around.

Skills and hobbies show that you’re passionate about something, that you’re active, and that you have status and intelligence. These are all important factors that make you more attractive to women.

### What makes for a good hobby

A good hobby that increases your attractiveness has to meet one or several of these criteria:

- It makes you the center of attention
- It places you around women
- It forces you to compete with other men (in person)
- It lets you demonstrate applied intelligence…
- … Or applied athleticism

You should probably have more than one hobby (and no, playing video games doesn’t count). Below are some suggestions to kickstart your brainstorming process:

### Hobby ideas for guys

There’s no shortage of hobbies that increase your attractiveness and set you up to meet new women. Here are a few ideas:

- Improv theater
- Volunteer work
- Language courses
- Competitive fighting
- Salsa dancing
- Crossfit
- Chess
- Join a band
- Politics (become a candidate/leader)

My personal hobbies/passions are boxing (I used to be a professional fighter), chess, languages, and travel.

When you try out new hobbies, you want to think about what categories they belong to. Make sure to cultivate several, varied hobbies. By cultivating a wide range of interests, you not only lead a more varied life but you also make yourself more interesting and perhaps even a little mysterious. **In the world of romance, 1+1=3.**

Just like being in shape and dressing well, cultivating a set of hobbies makes you attractive in more than just one way:

- It puts you around women
- It gives them a reason to admire you
- It makes you more confident

### Not hobbies, but almost: the importance of practical skills

A major reason why hobbies make you more attractive is that they enable you to demonstrate competence in a specific field. (The same applies to dressing well, by the way.)

[**Women are attracted to men that are competent**](https://bpspsychub.onlinelibrary.wiley.com/doi/abs/10.1111/j.2044-8260.1974.tb00872.x)**.**

This truth really goes beyond the sphere of hobbies. Women are also attracted to men who are competent in social settings (more in this later) and in practical everyday settings.

Something that doesn’t get talked about very much in modern dating advice is how important it is to develop practical skills. Do you know how to put up a shelf? Do you know how to change a tire? Can you cook a decent meal?

As a man, you should at least know some basic plumbing skills, basic mechanical skills, basic cooking, and basic construction skills (in other words, you should know how to use a screwdriver and you should be able to do basic home improvements).

## How to talk to women

The most important area of competence is interpersonal skills. **If you want to have success with women, you need to learn solid social skills.**

Besides physical attractiveness, social ability—confidence, dominance, extraversion—is the most important factor in creating attraction with the opposite sex. Guys that display the qualities of extraversion are rated [more favorably than their introverted counterparts in 4 out of 6 measures](https://psycnet.apa.org/record/1972-06715-001). Guys with a sense of humor are perceived as [significantly more attractive than their more earnest counterparts](https://www.tandfonline.com/doi/abs/10.3200/JRLP.143.1.67-77). Expressive, extroverted people are more likeable than reserved people.

You need to know how to approach strangers, how to have small talk, how to hold a conversation, and how to create rapport.

If you’re very shy or introverted, this might sound scary. But it’s actually good news: your social skills are far more malleable than your facial features or height. Even if you’re super awkward right now, you can improve dramatically through some basic research and lots of practice. And just because you are temperamentally an introvert, doesn’t mean you can’t learn and exhibit extroverted traits.

Even if you’re not super awkward, I’m gonna take a wild guess and say you don’t go out of your way to make new friends.

A lot of guys stick with the same group of friends throughout their lives. That’s fine. I’m not saying you should ditch them.

I am saying, however, you should make new friends—and get more comfortable creating connections with people you don’t know that well.

Why? Several reasons:

1. You’ll have more fun
2. It’s a challenge
3. You’ll develop a different aspect of your social skills: how to meet new people
4. You’ll become more comfortable in your own skin and feel more confident
5. You’ll meet new people, and many of them will be girls

### How to improve your social skills

There are lots of resources that can help you hone your social skills. The YouTube channel [*Charisma on Command*](https://www.youtube.com/c/Charismaoncommand/) is a good example: they have playlists on flirting, body language, confidence, and even persuasion.

But as great as YouTube may be, very few things can beat a solid, battle-tested book. If you haven’t done so already, you need to pick up and read Dale Carnegie’s famed classic, [*How to Make Friends and Influence People*](https://www.amazon.com/dp/0671027034)*.* It’s a must-read if you want to improve your social skills.

Take the knowledge you gain from that book and apply it to whatever groups of people you plan to make friends within.

### Leverage your hobbies and interests

If you read the previous section of this article, you already know how important hobbies are in making you a more viable candidate for dating. One of the reasons hobbies are so powerful is that you can leverage them to meet new people.

Shared hobbies and interests provide the perfect excuse to strike up conversations with people you’ve never talked to before: You’re in a safe, low-stakes environment, you already have something to talk about, and the other person already knows who you are (probably).

### The cheerleader effect

Ever heard of the “cheerleader effect”? It’s a cognitive bias that causes people to think individuals are more attractive when they’re in a group.

The name suggests that its effects are limited to women in groups, but research shows that [men are rated as more attractive](https://theconversation.com/yes-the-cheerleader-effect-is-real-and-you-can-make-it-work-in-your-favour-92501) when presented in a group as opposed to individually. This is another side benefit of being more social.

### How to stop being awkward around girls

There are girls out there who like shy guys. But on balance, being shy or awkward is **a major obstacle**. Like I’ve said before, women are attracted to competence—*especially* social competence.

There are several reasons why you might experience shyness or awkwardness.

If you’re otherwise socially able, but choke up when talking to girls, you probably 1) need more practice and 2) need to stop watching porn.

Now, if that’s not you, and you’re still awkward, all you likely need are some pointers here and there (Charisma on Command comes in handy here) and above all else, practice.

### What not to do (pick-up lines, rehearsed scripts)

What you never want to do when talking to women is use cheesy pick-up lines or rehearsed scripts. Pick-up lines are not charming (even if you try to pass them off as ironic), they’re annoying.

There are two secrets to creating chemistry: be interesting, and don’t try too hard. Pick-up lines somehow manage to be boring and uninventive, and try-hard acts of desperation—all at the same time.

**I’m telling you to be friendly and social—not to run game.**

When I tell you to meet women, that’s exactly what I mean. *Meet* them. A lot of guys have a “pussy or bust” mentality. That’s wrong.

You need to be able to just *befriend* women:

- Desperation kills attraction
- Having female friends is immediate social and romantic proof. If women see that other women actually want to hang out with you, it probably means you’re not a creep or a serial killer
- Your female friends will probably be friends with a lot of single women that you can now meet

Befriending a girl isn’t the same as settling for the friendzone, mind you. If you are into a girl but she’s not into you, **it’s better to just move on.**

### Build social capital

Your goal in all your social endeavors should be to build social capital, plain and simple. That’s what you’re doing when you befriend women. It’s also what you’re doing when you befriend other guys.

In the beginning, especially if you haven’t had a very active social life beforehand, you have to take the initiative 90% of the time. Invite the people you meet out for drinks or coffee, arrange activities and get-togethers.

Eventually these efforts will pay off.

When you’re polite, interesting, and know how to make friends, a few things happen:

People start introducing you to their friends…

You get invited to places…

And you meet a lot more women.

Eventually, you will have more party and event invitations than your schedule can accommodate.

## Do women care about money?

Now for a controversial question that a lot of guys get wrong.

**Do women care about money?**

Yes, women care about money. Women are evolutionary primed to be attracted to men that can provide for them and their future offspring. Marriages in which the woman makes more money than the man are [33% more likely to end in divorce](https://www.wf-lawyers.com/divorce-statistics-and-facts/).

Research from Australia shows that both women and men are [unhappier when the woman is the main breadwinner](https://nationalinterest.org/blog/buzz/does-relationship-suffer-when-woman-makes-more-money-131657).

Another reason why women find guys who have a lot of money attractive is because wealth is a sign of ambition, drive, and competence in some particular field. Like I mentioned before, competence is extremely attractive.

### Most women aren’t gold diggers

This isn’t to say that women are just gold diggers who are out for your money. But they do want to feel safe and protected by their partner—not just physically, but financially too. It’s not politically correct to point this out, but relationships are happier when the man is masculine and the woman is feminine.

Most women are not gold diggers, but *some* are. If you’re balling, you have to watch out so you don’t get played. Know this: you attract what you project. If you use your money to buy Ferraris and Rolexes to flash your wealth, most of the women you attract won’t be attracted to you, but the things you own. Maybe that is partly why the extremely wealthy in society [hide their wealth](https://fs.blog/2019/11/signaling-countersignaling/).

### The significance of social status

Just as much as wealth, women are attracted to men of high social status. The two are often closely interlinked, but not always. Think about the starving artist trope, for example: high-status, but no money.

Guys also care about social status. Deeply. Why do we go after girls who are more physically attractive? A big reason is that being with them raises our own social status. We become the envy of our friend groups and we make our parents proud.

Women are the same way. They want to be with guys that raise *their* social status.

Your educational level, social class, and choice of profession all factor in here. Being a doctor is higher status than being a successful investment banker, despite the latter probably making more money. Being a university professor is higher status than running your own plumbing business, even though you’re more likely to get rich doing the latter.

Also consider that social status is contextual: what is considered high-status in Brooklyn, NY is not necessarily considered high-status in Mobile, AL, and vice versa.

## Personality traits that make a man more attractive

If your personality is strong enough, you can overcome nearly any other flaw—being ugly, being poor, not having any real skills—in order to create attraction (at least short-term attraction).

Now, I’m not suggesting that you turn yourself into someone you’re not. But if you want to become more attractive to women, there are three qualities that you should be actively developing and honing:

### Confidence

Women are attracted to men who are confident. They love an alpha male who will take charge of the situation. Confidence is especially important when making the first impression, psychologist Dr. Sean Murphy [explains](https://www.spsp.org/news-center/blog/romanticconfidence):

> What makes confidence so attractive? One reason is that a lot of the things we want in a partner are difficult to observe directly, especially on first meeting - this includes traits like competence, drive, social status, and kindness. Because we trust that people know themselves well, and assume that their confidence (or lack thereof) reflects their actual value as a partner.

Learn how to hold eye contact, strike up conversations, and be assertive. Once you do that and stop second-guessing yourself, you’ll appear a lot more attractive to women.

If you struggle with self-confidence, I have written a very actionable guide for you, talking about the root causes of self-confidence and how to attain it. Check out [The Four Confidences.](https://mind-and-fist.ck.page/4f65ddeea7)

Once you're confident in yourself you'll have no problem serenading your girl during karaoke night.

### Ambition

[Drive is magnetic](https://www.independent.co.uk/news/uk/this-britain/women-sniff-out-ambition-sexual-partner-while-men-eye-good-looks-9191693.html). For several reasons: not only is it inspiring to see someone with ambition—if you are working towards a greater goal in life, it means that you’re not going to be needy or desperate when dealing with women.

It also means that you have potential—and some research (with dodgy methodology, but still) indicates that women are just as [attracted to earning potential](https://www.westernsydney.edu.au/newscentre/news_centre/story_archive/2012/its_not_about_the_money_research_reveals_women_are_more_interested_in_a_mans_earning_capacity_than_the_size_of_his_wallet) as they are to wealth in itself.

Find something to be passionate about, and then work toward it with intensity and consistency. And never apologize for being ambitious.

### Humor

Some guys can get away with being dark and broody. But having a sense of humor is actually one of the most important personality traits when it comes to attractiveness. It shows that you’re creative and [at least somewhat intelligent](https://www.sciencedirect.com/science/article/abs/pii/S0160289611000523).

Building self-confidence, finding something to be passionate about, and allowing yourself to be funny, are all things you can do without “faking” your personality or pretending to be someone you’re not.

## Frequently asked questions about becoming an attractive man

How can a man become more attractive?

Focus on fitness, grooming, style, personality, and building social status.

  What makes a man attractive to women?

Confidence, physical fitness, ambition, and social competence are the biggest drivers.

  How can I become more physically attractive as a man?

Improve your physique, grooming, posture, and clothing fit.

  How long does it take to become attractive?

Most noticeable improvements happen within 3–6 months with consistent effort.

  Do women care about looks in men?

Yes—but less than men do. Personality and status often matter more.

  How can I look more attractive as a guy?

Wear fitted clothes, maintain grooming, build muscle, and improve posture.

  How can I become more sexually attractive as a man?

Develop confidence, assertiveness, and physical presence while maintaining good hygiene and fitness.

## Focus on the 80/20

Countless books have been written about romantic attraction. The dating advice industry is worth tens of millions of dollars. There are a million things you *could* do to improve your attractiveness.

But everything comes with a price: each minute you spend worrying about some minor detail, is a minute you could have spent optimizing your life in some different way.

Focus on the 80/20. Identify where you can place 20% of your effort to get 80% of the results.

If you’re already physically fit but have a terrible dress sense, step up your style game.

If you lack interesting hobbies or social settings in which you can meet women in a natural way, take a look at what activities are available near you and try some of them out.

To summarize my main points, these are the things you should focus on if you want to become a more attractive man:

- Your physical shape and grooming
- Your hobbies, leading an interesting life
- Honing your social skills
- Developing an attractive personality

You don’t need any PUA techniques. You don’t need to drive a Ferrari. You don’t need an expensive Rolex on your wrist.

While those things will certainly help you attract girls (especially the kinds of women that like those things)… Not having them is not what is holding you back.

In order to become successful with women, you only need the fundamentals. After all, hundreds of generations of your male ancestors *didn’t* have Ferraris or PUA blogs… And yet here you are, somehow.

But whatever you do, make sure to actually *take action*. All this knowledge I’ve shared is useless if you don’t apply it to your own life.

## Become more attractive without turning into a d-bag

 [Get the short free guide here](https://mind-and-fist.ck.page/ae776819a8)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
