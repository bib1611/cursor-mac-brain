# How to get into boxing: amateur or pro

- **Source:** https://edlatimore.com/how-to-get-into-boxing
- **Date:** 2021-12-22T17:25:03.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 28717 chars

## Body (verbatim, study/swipe)

I started boxing at the ripe old age of 22. I say it that way because that is a relatively late age to take up boxing.

I had no prior experience in any combat sports. All I had was a curiosity about the sweet science and the attitude that I wouldn’t quit. I said to myself that the only way I’d stop boxing is if I got severely injured or suffered so many losses that I couldn’t get a fight.

Fortunately, I didn’t get beat out of the sport with repeated injuries or losses. In fact, I went on to have a great amateur and professional boxing career. As the sport has grown worldwide, fans now follow every major fight closely, with many even exploring [boxing betting](https://indian.1xbet.com/en/line/boxing) to add extra excitement to the action

As an amateur boxer, I:

- Was the 2011 201+ lbs Pennsylvania State Golden champion
- Was the National P.A.L. champion at 201+ lbs
- Achieved a national ranking of 4th according to TeamUSA Boxing
- Had notable amateur victories over Olympian and 2x world title challenger Dominic Breazeale and IBF Heavyweight world champion Charles Martin
- Finished my amateur career with a record of 48-11

My record in national level tournaments includes victories over Charles Martin and Dominic Breazeale

As a professional boxer, I was represented by Roc Nation Sports and achieved a record of 13-1-1.

I was coached by Hall of Fame boxing coached Tom Yankello. If you don’t have a hall of fame level coach near you, don’t worry. You can learn from in any one of the [videos from his World Class Boxing Academy.](https://www.worldclassboxinggym.com/shop-videos?ref=EDLATIMORE)

I think the videos are great, but I’m not just biased. Tom has the following accolades:

- 2025 National Italian American Hall of Fame
- 2025 Pennsylvania Sports Hall of Fame
- 2022 Pennsylvania Boxing Hall of Fame
- 2014 Beaver County Sports Hall of Fame
- 2007/2008 Honorable Mention to Official Top 5 Trainers in the World by Doug Fischer, *Ring Magazine*
- “Tom Yankello teaches boxing the right way.” – Roy Jones Jr., former four-division world champion and one of the greatest pound-for-pound boxers in history
- “Smartest trainer in boxing, period.” – Paul Spadafora, former IBF Lightweight World Champion and undefeated in 49 professional fights
- “If I were managing a fighter & needed a trainer who could take us all the way, Tommy Yankello would be on my short list. What he does with his talent is very impressive. His passion & enthusiasm for the sport, & his commitment to his fighters, is as good as anybody’s.” – Joe Tessitore, ESPN Boxing

If you’re new to the sport or want to get started, his video series will give you a series leg up on your path to learning the sweet science. Check out his videos in the [World Class Boxing Academy Video Series here.](https://www.worldclassboxinggym.com/shop-videos?ref=EDLATIMORE)

This article tells you everything you ever wanted to know about getting into boxing and the different paths you can take. I’ll also tell you the pros and cons of each path. I want to give you a realistic picture of boxing, both as an amateur and professional.

Because of the movies, too many people have a romantic view of boxing. Before you start training, you should understand what you’re getting into. While this is meant for beginners, I urge veterans to weigh in and message me if you see anything I left out that you think someone interested in the serious pursuit of boxing should know.

## Things you need before your first day at the boxing gym

### Minimal fitness level to start boxing training

I understand that many people use boxing to lose weight and get in shape. However, a fighter uses boxing to compete, make money, earn honor, and gain fame. So if you want to box competitively, you already need to have a minimal fitness level.

While nothing gets you in shape for fighting but fighting, the following is a list of the things you should be able to do before you enter the gym. An explanation will follow.

- **Run 2 miles in under 15 minutes.** Boxing is an aerobic sport and you’ll need the cardio to train for hours.
- **At least 6 100-meter sprints with no more than a 30-second break in between.** This trains the body’s anaerobic system and improves your [body’s ability to use oxygen under intense duress.](https://www.healthline.com/health/vo2-max#increasing-vo%E2%82%82-max)
- **Jump rope for at least 15 minutes straight.** This is more mental than physical. We’re concerned with your ability to do something physical without a break in concentration.
- **Do 50 sit-ups in a row and push-ups in a row.** You need strong abs to deal with body blows, transfer force, and help you keep your balance. Strong arms help transfer force from your core into your fist and make you better able to defend. We test the strength this way because everything in boxing is about endurance instead of raw strength.

I can’t imagine that any gym will test if you can perform these feats before they let you train, but being at this level of conditioning makes it easier to box. A coach will see that it will take less work to get you ready to fight. You’ll also be able to start sparring faster, which means you’ll learn how to fight faster.

Remember: being in general shape is important, but being in fight shape matters. The only way to get into fight shape is by fighting, but to carry yourself through the sparring sessions where you learn how to fight, you need to be in good general shape.

 [Learn more about my training routine How to train for a boxing match: Insights from a pro](/boxing-training)

### The right attitude

Boxing is difficult.

You not only have to be in supreme physical condition, but you also have to learn a new way to move your body and deal with pain and discomfort. This means you need the right mindset. Otherwise, the training will crush you.

And if you try to skip the training, [not only will not be able to punch with power](https://edlatimore.com/how-to-punch-harder-the-physics-and-biomechanical-drills-to-make-you-a-knockout-artist), you’ll get clipped by someone’s powershot.

From my experience, here are the most useful attitudes you need for boxing:

#### **There is no winning or losing; Only learning.**

I once watched a fighter win his first nine amateur bouts, lose his 10th, and quit because he didn’t think boxing was for him because he lost. While boxing is a competitive, zero-sum sport, you have to accept that you will, at some point, lose.

No fighter was undefeated their entire amateur and professional career. Even if that fighter did exist, he certainly didn’t get that way without taking some ass-kickings in sparring.

I’m not telling you to accept losing. You need a competitive drive to succeed. But don’t let it discourage you.

#### **The difficulty of something is irrelevant if it’s vital to your success.**

This mindset extends beyond the obvious physical challenges of boxing. At some point, you’ll need to train like a full-time job but will earn nothing. In fact, after factoring in fees, gear, memberships, tests, and travel, you’ll most likely be in debt.

You won’t be able to work in many places because of the time commitment. Even flexible retail positions may be wary of you after your first time working with a black eye. Then there are the emotional letdowns of opponents backing out at the last minute (this happens at both the amateur and professional levels).

You’ll have to learn to accept these difficulties in stride and just take them as part of the game. This is why boxing is my favorite metaphor for life. Life is just as difficult as boxing, so if you can succeed in the ring, you can succeed in life.

#### **Given enough time and the right instruction, I can learn anything.**

We all start with different strengths and weaknesses. I had a killer hook and didn’t need much help developing it. However, my straight punches were terrible. It took me nearly six years to develop a decent jab and two more to develop a decent straight right.

I just committed to getting better and absorbing my coaching. Picking the right boxing coach is important, but your approach to learning is even more important.

### The right boxing equipment

You need your own boxing gear.

I started my career using community gear at the gym, but I don’t recommend this. For starters, it’s disgusting. While some high-end clubs and gyms will have people who clean the community gear, those places don’t usually cater to serious fighters.

Secondly, it shows that you’re serious if you invest in yourself. I’m not saying that you need to have the best boxing gear on the market, but you need to have some gear of your own.

Lastly, regardless of how comfortable you are with community gear, there are some things that you simply can’t share. Boxing shoes and mouthpieces immediately come to mind. Here is a list of the gear that you need to box.

**Protective headgear.** You won’t need this when you’re just starting because you should have a little time to learn proper punching technique and footwork before you start sparring. Eventually, though, you’ll need a sparring headgear with cheek protection. Some headgears have an open face, only padding the rest of the head. That’s not what you need to get started.

Sparring headgear on the left. Can be used in competition and provides the most protection. Open face headgear on the right for some competitions and is not good to use in practice because it provides less protection.

**Hand wraps.** Hand wraps stabilize the wrist and hold the bones of your hand in place. Your coach will teach you how to wrap your hands, so don’t worry if you have no idea how right now. As most gyms have them, you can use community wraps, but you should get your own quickly. Of all the items on this list, these are the cheapest.

**Gel wraps** (optional, but I’m a big fan). These are wraps that are more like gloves with gel padding on the knuckles and a single velcro support around the wrist. Optional to have. I enjoy them though.

**Mouthpiece.** I recommend spending the money and getting a custom mouthguard. Your dentist can do it or order one from [The Mouthpiece Guy](https://www.mouthpieceguy.com/). This isn’t an affiliate link. I just think it’s a great product. Much better than what you’ll find on amazon looking up “boxing mouthpieces.” But if his prices are too high, there are a variety of mouthguards on Amazon or at any sporting goods store that will do the job,

**Boxing shoes.** Wrestling shoes work just as well, but you’ll eventually want to get shoes specifically designed for boxing. If you’re curious, this article goes over [the difference between boxing and wrestling shoes](https://www.livestrong.com/article/153371-what-is-the-difference-between-boxing-shoes-wrestling-shoes/), but you eventually need to get a pair specific to boxing.

Boxing shoes can run you anywhere from $50 to $250+. Generally speaking, you get what you pay for but there are some decent discounts. These shoes will last a while, as you aren't constantly walking in them.

**Groin protection**. More commonly known as a “cup” or “boxing cup.” You want to not only protect yourself from the (not always) accidental groin shot, but you also need to protect your hip bones.

**Heavy bag gloves and sparring gloves.** Two types of boxing gloves are used in training (we don’t need to worry about competition gloves). Bag gloves are smaller than sparring gloves and the padding is distributed differently. Sparring gloves will be no lighter than 16 oz., but I’ve seen them as big as 20 oz.

This is for protection, as that weight is composed of extra padding. Bag gloves shouldn’t be heavier than 14 oz., but when I turned pro, I started hitting the bag with 10 oz. gloves to mimic competition.

You don’t spar in bag gloves but you can hit the bag in sparring gloves. A quick way to get kicked out of a gym is to wear sparring gloves smaller than 16 oz. without permission. Yes, highly skilled guys will sometimes spar in lighter gloves to mimic competition, but that’s not you.

[***Here are my specific boxing glove recommendations***](https://edlatimore.com/pro-boxer-best-boxing-glove-recommendation)

Because I don’t have a preference or loyalty to a specific brand, my amazon store affiliate link is below. If these suggestions help you, I’d appreciate if you bought through the link so I can get a small (and I do mean ***small***) commission.

- [Get boxing gear here](https://amzn.to/3Fozxov)
- [The Mouthpiece Guy](https://www.mouthpieceguy.com/)

With the prerequisites out of the way, let’s get into the various ways you can start boxing.

## Amateur boxing vs Professional boxing

You must know the difference between amateur boxing and professional boxing. Something I’ve learned over the years is that the average person (i.e. most people) doesn’t even know that amateur boxing exists, let alone the difference between “the pros and ammys”.

> Most people don’t know shit about boxing.
>
> -Roger Mayweather

### Major differences between amateur and professional boxing

|  |  |  |
| --- | --- | --- |
|  | **Amateur boxing** | **Professional boxing** |
| ***Earnings*** | - No money for winning the fight. - Can receive sponsorships, but are extremely rare. | - Earns a “purse” for winning the fight. - Can receive sponsorships, are much more common |
| ***Protection/Coverings*** | - Headgear - Shirt - Cup | - No headgear - No shirt (in men’s boxing) - Cup |
| ***Glove size*** | - Fighters under the light welterweight class (141Ib.) commonly use 10 oz. gloves - Fighters in classes welterweight (152Ib.) through super heavyweight (over 201Ib.) most commonly use 12 oz. gloves - Masters Division fighters, who are 41 years of age and older use 16 oz. gloves | - Fighters in the welterweight (147Ib.) class and under most commonly wear 8oz gloves - Fighters in classes super welterweight (154Ib.) and up commonly wear 10oz gloves - Glove sizes are negotiable depending on what is negotiated. |
| ***Boxing rIng size*** | - Ring size can be no smaller than 16x16 feet and no larger than 20x20 feet. | - Size of ring can vary |
| ***Numbers and length of rounds*** | - Always three rounds - Two-minute rounds for Sub-novice (less than 3 fights) and certain tournament conditions - Three-minute rounds others | - Can be 4, 6, 8, 10, or 12 rounds. - Always 3-minute rounds |
| ***Scoring system*** | - Same, though knockdown rules vary more than professional | - “10 point must” system |

These are the major differences. This chart can best be summarized this way: ***Professional boxing is more dangerous and requires you to be in better shape, but at least you get paid for the risk.***

Boxing (and other combat sports like kickboxing and MMA) is unique in that there is no requirement for you first to be an amateur. There are several reasons for this that are beyond the scope of this article, but the important thing to realize is that there is no rule that says you *have* to be an amateur before you turn pro.

This means that if you wake up tomorrow and decide that you want to be a pro boxer, there’s nothing that can stop you from getting a fight. You’ll almost certainly lose, but you can do it.

That means you could immediately start earning money immediately. So why doesn’t every fighter go that route? Well, there are some pros and cons to each path.

### Should start as an amateur boxer or a professional boxer?

You should definitely start an amateur boxing career first. The only notable fighter I found with no amateur boxing experience was former Junior Welterweight [Chris Algieri](https://en.wikipedia.org/wiki/Chris_Algieri). However, even he had amateur combat sports experience in kickboxing.

If you want to do anything more than brag to your friends that you’re (technically) a professional athlete, compete in amateur boxing first. The age limit is 35 before you’re forced to compete in the master’s division against other 35+-year-olds.

If you insist on boxing at the professional level without any amateur boxing experience, at least get experience in another combat sport with striking. Kickboxing and MMA immediately come to mind.

## The Mental Edge Most Fighters Ignore

Finally, there’s a supplement that improves your reaction and reduces the number of mistakes you make.

Mind Lab Pro has been proven to reduce reaction time by 12%. That’s the difference between slipping a punch, blocking it, or getting knocked out.

Mind Lab Pro also cuts anticipation errors in half. In other words, Mind Lab Pro will make it much harder for your opponent to pull of fients and distract you.

If you’re serious about your training, pick up a bottle of Mind Lab Pro.

It even comes with a 30-day, no-questions-asked, money back guaranteed.

 [Up your boxing game](https://www.mindlabpro.com/?a_aid=698b400c4a47f&a_bid=6d45f5c3)

#### Reasons why you should be an amateur boxer first before turning professional

The biggest reason to be an amateur boxer first is that it gives you a chance to develop your skills. When you lose an amateur fight, no one cares. Your record in amateur boxing competitions doesn’t carry over into your professional career.

You could be the biggest loser in amateur boxing, but when you turn pro, your record is officially 0-0-0. This means you can take the time to learn your craft and not worry if you win or lose most fights.

Every loss you suffer as a professional is permanent. It will cost you if you suffer too many losses. You’ll never get a chance to fight for a belt of any significance. You’ll also never be able to make any significant money except as a “B-side” fighter, the fighter brought in who is most likely to lose.

***[My first loss as a professional was an embarrassing, televised affair, but I took 8 important life lessons from it. Read them here—>***[***Dealing with getting knocked out: Lessons from losing a fight***](https://edlatimore.com/8-valuable-life-lessons-ive-learned-from-losing-on-national-television)***]***

There is one other major perk of starting as an amateur fight: it gives you a chance to get the attention of a boxing promoter. Having a promoter in boxing is the ultimate prize. They’re the ones who can get you on television or major fight cards.

With a promoter, you’ll be brought along correctly, fighting fighters of the right level that you should win against because you’re the A-side, but will challenge you. Without a promoter, you’ll likely fight a bunch of easy fights and then jump multiple levels to a fight that you can’t win, but your record makes it easy to sell the fight, not only to the networks but also to the state athletic commission for approval.

This is the route to becoming a boxing champion and/or making a significant payday.

This is accomplished by winning a major amateur boxing event. WInning one of the following amateur championships—or even finishing in the top—gives you a better chance at getting a promoter and making more money as a profession:

- The National Golden Gloves
- The Pan American Games
- Commonwealth Games
- AIBA World Boxing Championships
- The Olympic Games (even making it to the Olympic games is enough to get attention)

Fighters with a few losses aren’t marketable as prospects for a promotional outfit to pick up, but they are useful to develop the record and abilities of the fighter that the promoter has signed and invested in. These fighters become what is known in the boxing world as “tomato cans,” “opponents,” “journeymen” or “gatekeepers.”

- Tomato cans are easy wins to build a record and get experience. They’re so named because they fall over easy and spill red (blood) everywhere.
- Opponents are tough guys who can fight but will never be good enough to take on big fights. They almost always have an “upside-down” record (more losses than wins), or they have a lot of wins and losses (usually in the double digits).
- Journeymen are usually guys who have a few losses, but they have many wins. Many of these guys stuck around long enough to learn how to fight well but didn’t have the backing to get developed properly. As a result, they have a few losses.
- Gatekeepers are guys whose only losses have come against top competition. You must beat these guys before you get a shot at fighting for a title.

## How to start boxing

Now that you understand what you’re getting into and need to get into it, the rest is how to start your boxing training.

 [Learn how Boxing changed my life. I think it will change your life too. Here are 8 ways boxing will transform your life](/boxing-benefits)

### Find a boxing gym

Even in the time of the internet, many boxing gyms don’t have a website. A lot don’t even have a social media presence.

You may have some luck finding one by doing an internet search. However, I recommend you do something else rather than do a broad search online. The following suggestion assumes that you don’t know anyone who fights. If you do, just ask them where to go.

#### How to find a boxing gym in your area

If you have a decent boxing gym in your area, it’s likely produced some press-worthy fighters.

Fighters tend to get press for winning major amateur tournaments a professional bout. Do a google search for “boxers in [insert your city]” or “boxers from [insert your city]. Once you have a fighter’s name, you should be able to look him up on social media and shoot him a message.

Boxers love Instagram. I’ve yet to meet one without an Instagram presence. Fortunately, Instagram makes it easier to send people messages to people than any other platform. You just have to follow them.

***In this article, I tell you how to find a good boxing gym along with some other boxing tips—>***[***25 boxing tips for amateurs and professionals***](https://edlatimore.com/25-boxing-tips)

### Make sure the gym is easy to get to

I’m assuming you are already disciplined enough to practice at least 5 days/10 hours weekly. To make it easier for you to stick with your commitment to training, choose a gym that’s easy for you to get to.

That was ensuring that my first gym was on a major bus line because I didn’t have a car when I started fighting. Knowing that I’d always be able to get to the gym made it much easier to stay committed.

The gym doesn’t have to be near you if you have a car. However, understand that many trainers don’t operate boxing gyms full-time. This means you’ll most likely have to get there during rush hour, whenever everyone is getting off work, including you and your trainer.

In short, pick a gym that’s easy to get to so you don’t have proximity be an unnecessary difficulty.

### Give it 500 hours

Train at the gym for at least 500 hours before you decide if you should stay or not.

500 hours of training equates to approximately 10 hours a week for a year. If you train at that pace, that gives you enough time to learn about the other gyms and coaches in the area. You’ll have sparred and should have fought in a few bouts as well (whether you’re an amateur or professional).

This experience will allow you to not only determine if you’ve found the best coaching match for your personality, but also to see if you really want to box. I always tell guys that they don’t know if they really like the sport without at least spending a year seriously training.

### Judge a gym by effort alone

The old idea was that the best boxing gyms tend to be in the worst neighborhoods.

I don’t know how much truth there is in this, as a whole, but it has been my personal experience that there are good gyms in great neighborhoods and bad gyms in bad ones. Boxing is a tough sport; bad neighborhoods have tough people, but toughness isn’t the only quality required to succeed. Also, [growing up in a bad neighborhood](https://edlatimore.com/the-projects) isn’t the only way to develop toughness.

When you evaluate a boxing gym, don’t get caught up in how new or old it looks. Look at how well things are maintained.

See how the fighters in the gym interact with one another and the coach. You’re looking for an atmosphere of respect. Ego isn’t necessarily a bad thing, but the fighters in the gym need to show reverence for the sport, treat the equipment well, and the place needs to be clean.

### Learn by video from the right instructors

There are a few good coaches out there, but you have to be careful. Learning the wrong thing is often worse than learning nothing at all. Especially in something as serious as boxing—and especially. if you decide to purchase a video course.

There are few things worse than thinking you know how to fight because you watched a few YouTube videos and you get cleaned out and you get completely turned off from the sport.

### Evaluating the coach

My coach Tom Yankello is one of the best teachers that I know. Here he is in the ring, instructing during a sparring session with me and another fighter.

**The most important trait for a coach to have is the ability to teach.**

A track record of successful fighters doesn’t mean as much as you think. It’s certainly worthwhile, but I’ve seen several coaches get lucky with an incredible talent who walks through their doors. Because of this talent and his success, other talented fighters followed and suddenly, it looks like the coach is a master trainer.

**You’ll have to see if a coach has a reputation as a teacher and instructor.**

There is no sanctioning body for a coach’s skills and knowledge to be tested against to determine if he can do the job. While amateur boxing forces coaches to take a class to work a fighter’s corner, that’s more to teach them the rules and not for the education of the boxer. I say this to warn you that many coaches don’t know how to teach the sport.

**Look at how the coach trains his fighters.**

Be wary of any coach that overly relies on pure physical conditioning. While boxing is a physical sport, coaches that push physical training in the place of skills development usually lack an understanding of the skills required to fight.

**Another thing to watch is the coach’s approach to sparring.**

Sparring is a classroom. While you must learn how to fight, the coach shouldn’t encourage sparring sessions to be all-out brawls. Especially if you aren’t getting ready for a fight.

Sparring sessions are education sessions. It’s a hard education, but it’s an education nonetheless.

### Have a little money

Boxing is a poor man’s sport. If you’re strapped for cash, most of the equipment can be acquired cheaply (mouthguards) or there is used community gear (everything but shoes).

I can’t speak on anywhere but the United States, but here you’ll need to pay for membership to USA Boxing to compete in any amateur boxing fights

The last time I checked, the fee was $50. That $50 goes towards blanket insurance if you get injured fighting in a sanctioned USA Boxing event, it pays the wages of people who work events. It enters you into the amateur boxing tracking system. You can’t officially fight without paying that fee.

If you’re a professional, you have to pay for blood tests, medical examinations, and fees to get your federal and state licenses. You can’t fight without any of these things. Some states are more rigorous in their medical examination and blood work requirements than others, but every state has *some* test you must pay for.

If you don’t have a way to pay for this stuff, find one. You can’t fight without spending a little money. Even “Smokers”—unsanctioned fights that may or may not follow professional rules—force you to pay an entry or registration free.

## Closing

If I’ve done my job well, you should better understand what it takes to fight. At the very least, you realize that it’s a hard way to make an even harder living. With that said, it is immensely rewarding and teaches you many lessons about life that can only be learned the hard way.

***[The life of a fighter is rewarding, but I eventually called it quits. Here’s why—>***[***5 reasons why I quit boxing with only one loss***](https://edlatimore.com/why-i-quit-boxing)***]***

Hopefully, this guide will have given you everything you need to put the odds of success in your favor. However, this is only a guide. It may be a good guide, but you still have to train boxing to see if you can hack it.

Like the wise sage, former heavyweight champion Mike Tyson once said, *“Everyone has a plan until they get hit in the mouth.”*

The rest is up to you.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
