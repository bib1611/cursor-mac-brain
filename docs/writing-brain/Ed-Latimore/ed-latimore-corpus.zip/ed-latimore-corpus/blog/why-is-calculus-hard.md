# Why is calculus hard?

- **Source:** https://edlatimore.com/why-is-calculus-hard
- **Date:** 2022-10-20T13:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 9186 chars

## Body (verbatim, study/swipe)

At age 33, I received a bachelor’s degree in Physics.

But I wasn’t always good at math…

As a matter of fact, I was comically bad at it. In high school, I failed Calculus three times, which led me to believe I just didn’t have the brains for it.

If I went back in time and told my younger self that I’d end up obtaining a Bachelor of Arts Degree in Physics with a minor in mathematics – I’d probably think my future self was scamming or smoking something.

I finally passed Calculus my fourth time taking it.

With hindsight and wisdom, I have a better understanding of why Calculus was hard, and why it’s probably hard for you.

Here’s what I learned…

## You have a poor mindset about calculus

If you shudder at the thought of calc, it’s a fear response you likely learned from a bad math class experience a long time ago. Maybe it was the hardest class you took in high school, or worse, you ducked it all together and instead went with an easier course load.

You’re not alone either way.

An estimated 17% of people in the United States have math trauma.[1](#fn:1) This refers to the debilitating difficulty and brain shutdown that many people experience when encountering math.

It makes people avoid math and experience feelings of frustration and defeat.

I always thought that math skills were genetic… Either you were born with the skill or not. Many people even believe that certain cultures are predisposed to being good at math.

This limited mindset is a slippery slope since math courses only get more challenging. Adding and subtracting leads to algebra. Algebra is followed by geometry, trigonometry, and calculus courses.

I didn’t see a change until I believed I could learn calculus. I would have failed on my fourth, fifth, and sixth times as well if I hadn’t buckled down and dedicated myself to learning the concepts of calculus.

## Calculus uses conceptual ideas

People struggle with calculus because they don’t grasp the concepts.

In short, calculus is the study of infinitesimal changes. The original name is actually “The calculus of infinitesimals.”

After taking calculus for the fourth time, a lightbulb went off, because I learned the “why” behind the subject.

In a broad sense, calculus is the math we use to measure things that are changing. Other forms of mathematics and arithmetic are straightforward. Calculus deals with more abstract concepts.

Before you can comfortably delve into the abstract, you need to master the concepts. Learning and drilling calculus functions build your skill set so that calculus becomes less intimidating.

In my post, [“How to Learn Calculus (even if you’re bad at math)”](https://edlatimore.com/how-to-learn-calculus) I explain core concepts, such as derivatives, integrals, and limits.

Whether you’re taking a class or learning from a workbook, commit every function and theorem to memory right away.

Functions refer to problems that explore the relationship between two variables. Theorems are operations that prove or disprove statements.

Here are some core concepts you’ll want to learn and drill:

- Rolle’s Theorem
- Mean Value Theorem
- Trapezoidal Rule
- First, Second, and Third Order Derivatives
- The Squeeze Theorem
- Antidifferentiation of a Composite Function
- The Disk Method

Explore these concepts with practice problems until you understand them in practice, not just theory. The idea that anyone is predisposed to understanding high-level math is a misconception.

You’re only going to internalize these concepts by putting in time on task. Prepare to dedicate at least 12 hours a week to your calculus studies.

Newton read, wrote, and studied 18 hours a day, 7 days a week.[2](#fn:2) Geniuses are made, not born, so never shy away from the work.

## Your fundamentals are weak

Perhaps the biggest reason that people struggle with calculus is that they haven’t mastered the prerequisites.

When I was a pro boxer, it would have been nice to come out the gate throwing combinations like Roy Jones Jr. or exhibiting the footwork of Sugar Ray Robinson.

But before that, I had to learn to tuck my chin, “answer the phone” keeping my power hand close to my jaw, and pump out a piston-like jab to measure distance and collect data from my opponent.

What you don’t learn early can hurt you later.

The same applies to calculus. Before you can jump into differentation and integration to calculate rates of change and complex area and volume equations, you need to master the fundamentals…

Algebra. Trigonometry. Geometry.

**For Algebra, make sure you understand things like:**

- Polynomial expressions – i.e. (x+15)(7x−12)
- Quadratic equations – 11x² + 6x - 1 = 0
- Logarithms – bx = a ⇔ logb a = x

**Trigonometry skills that are essential to calculus include:**

- An understanding of sine, cosign, and tangent
- Graphing trigonometric functions
- Solving for triangular angles

**Some Geometry skills that you need for calculus include:**

- Computing the area of shapes like rectangles, circles, trapezoids, and triangles
- Graphic and writing out equations
- Learning and drawing lines of symmetry

Find out what areas you’re weak in and become a sponge figuring it out. Many mathematicians before you have developed systems and methods to make learning easier for them.

As mathematician Paul Halmos said, mathematics is not a spectator sport. These are skills that you gain passively or just by listening to someone talk about them. Solve problems and break them down step by step to know the method and reason.

## Sharpen Your Thinking, Not Just Your Skills

Finally, a supplement that’s proven to make it easier to learn math.

Mind Lab Pro has been shown to improve:

- Auditory memory by 11%
- Visual memory by

It supports the kind of sustained concentration, memory, and mental clarity that deep problem-solving requires — without stimulants that burn you out halfway through a session.

Because the difference between guessing and understanding often comes down to how well your mind holds up under pressure.

Train your thinking like you train everything else.

## Use the Feynman Technique

My understanding of calculus really took off when I began using the Feynman Technique. This technique was created by Richard Feynman, a Nobel-winning physicist, and can be used to learn and understand practically anything…

- On a sheet of paper, write out in plain detail what you’re trying to learn
- Write point by point each step of the concept like you’re teaching it to someone else
- Go back and simplify the steps in easy-to-understand language, and use analogies and mnemonic devices to help you commit them to memory
- Use your newfound understanding to put the concepts to use until you’re fully competent

Simply put, learning calculus is a long-term commitment. The reason it’s so hard for many people is that they’re not willing to fully commit.

Cramming can get you results in the short term, but mastering calculus or any other skill always involves consistent effort over time.[3](#fn:3)

Thankfully, we live in a time in which there are solutions for any problem you want to solve. You can master calculus in a more straightforward path than I did, while also getting over your past fears and misconceptions about high-level math.

Register for this [precalculus course on Udemy](https://www.udemy.com/course/trig-by-krista-king/) to take immediate steps toward learning calculus.

From there, the rest is up to you.

## Learn the method I used to earn a physics degree, learn Spanish, and win a national boxing title

- I was a terrible math student in high school who wrote off mathematics. I eventually overcame my difficulties and went on to earn a B.A. Physics with a minor in math
- I pieced together the best works on the internet to teach myself Spanish as an adult
- \*I didn’t start boxing until the very old age of 22, yet I went on to win a national championship, get a high-paying amateur sponsorship, and get signed by Roc Nation Sports as a profession.

I’ve used this method to progress in mentally and physically demanding domains.

While the specifics may differ, I believe that the general methods for learning are the same in all domains.

This free e-book breaks down the most important techniques I’ve used for learning.

 [Get the free book now](https://mind-and-fist.ck.page/0f2b0af82f)

---

### References

1. Dickinson, Kevin. *Big Think*. Can ‘math trauma’ hurt people’s finances? September 23, 2019. <https://bigthink.com/neuropsych/math-trauma/>. (Accessed August 29, 2022) [↩](#fnref:1)
2. *PBS*. Newton’s Dark Secrets. November 15, 2005. <https://www.pbs.org/wgbh/nova/video/newtons-dark-secrets/> (Accessed August 29, 2022) [↩](#fnref:2)
3. Paul, Annie Murphy. *Scientific American*. Why Cramming Gets a “C”. August 1, 2015. <https://www.scientificamerican.com/article/education-why-cramming-gets-a-c/> (Accessed August 29, 2022) [↩](#fnref:3)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
