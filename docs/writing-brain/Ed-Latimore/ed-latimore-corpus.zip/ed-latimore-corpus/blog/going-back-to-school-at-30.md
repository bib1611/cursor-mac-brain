# Going Back To School At 30: Why It’s Not Too Late To Change Your Life

- **Source:** https://edlatimore.com/going-back-to-school-at-30
- **Date:** 2020-03-06T10:39:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 27755 chars

## Body (verbatim, study/swipe)

## Is 30 Too Old To Go Back To School?

At age 28, I went back to school.

Although I had tried college immediately after high school, I failed after three semesters. None of my old grades were good enough to use for credit, so I started over from scratch.

My first semester began in January 2014. In May 2018, I graduated with a bachelor’s degree in Physics. I was 33 years old.

I won’t lie to you and say it was a park walk. It was difficult but doable.

Sometimes, I wasn’t sure how I would pay the rent. I even once had to borrow a significant sum from a friend. However, the personal and professional growth I experienced during those four years is worth ten times the cost of a typical college degree.

## Why Going Back To School At 30 Feels So Scary

Going back to school at 30 is scary because, unlike when you were 18, you fully understand what’s at stake.

When you’re younger, you often drift into college because it’s simply the next expected step after high school. You don’t fully understand debt, opportunity cost, time, or how difficult life can become if things go wrong. But by 30, you do.

By that age, many people have already experienced failure, financial stress, dead-end jobs, layoffs, divorce, or the realization that they built a life around a career path they no longer want. Going back to school doesn’t just feel like taking classes. It feels like gambling years of your life on the hope that things can still improve.

There’s also the fear of being “behind.”

You start comparing yourself to people who already have careers, homes, marriages, retirement accounts, or children while you’re sitting in a classroom wondering whether you made a huge mistake. You may even feel embarrassed about being older than your classmates.

I felt this myself.

When I went back to school, I was older than many of the students around me. I had already failed college once. I wasn’t naturally gifted at math. Sometimes I wasn’t sure how I’d pay rent while juggling school, boxing, Army National Guard drills, tutoring, internships, and trying to build my future all at once.

And then there’s the deeper fear most people don’t openly admit:

“What if I try again and still fail?”

That fear hits harder at 30 because your identity is more developed. Failure no longer feels like “just part of growing up.” It feels personal.

But here’s what many people discover:

The fear you feel at 30 is often a sign that you finally understand the importance of your decisions. That awareness can become an advantage instead of a weakness.

You stop drifting.
You stop wasting time.
You stop treating your future casually.

The pressure is higher, but so is the focus.

And ironically, that’s often why older students succeed.

## The Advantages of Going Back To School When You’re Older

Being older in college comes with advantages that younger students almost never appreciate until later in life.

When I first attempted college at 18, I wasn’t emotionally prepared for it. I got distracted by partying, drinking, socializing, and all the freedom that suddenly came with being away from home. I lacked discipline, direction, and urgency.

At 28, I approached school completely differently.

I understood how difficult life could become without useful skills. I understood the value of time. I understood what hard labor, financial stress, and uncertainty felt like. Because of that, I treated school as an opportunity instead of an obligation.

That shift changes everything.

Older students usually have clearer goals. They aren’t attending college because “that’s what you do after high school.” They’re there because they want something specific:

- a better career
- financial stability
- personal growth
- a second chance
- a way out of stagnation

That purpose creates focus.

[Older students also tend to manage time better](https://edlatimore.com/how-to-be-an-adult). While younger students are often learning independence for the first time, adult students are usually already balancing work, bills, family responsibilities, and other obligations. You become much more protective of your time and energy because you know exactly how limited both are.

Another advantage is emotional maturity.

At 18, small setbacks feel catastrophic. A bad exam grade can ruin an entire week. Criticism feels personal. Motivation constantly fluctuates. Older students are often more emotionally stable and resilient because life has already forced them to develop those traits.

You also stop caring as much about social pressure.

As a 30-year-old student, you probably aren’t worried about fitting into party culture, impressing classmates, or chasing distractions that derail your long-term goals. You’re there to get results.

Ironically, many people think going back to school later puts them at a disadvantage, when in reality, maturity, discipline, perspective, and urgency often make older students far more effective learners.

You may not have the raw energy of an 18-year-old.

But you usually have something much more valuable:

purpose.

## Why do you, personally, want to sacrifice four years to college?

Seriously. Why do you want to go back to school?

More specifically, why do you want to go back to school at 30?

Some people consider returning to school to pursue a new career, add to their skill set, or simply get more out of life. Others have hit a ceiling at their current job.

No matter your career goals, this article has something for you.

I detail my observations and experiences as an adult student in college. I can’t guarantee that all of my advice will work for your situation, but if you want this and are willing to do the hard work, you’ll get something out of this article.

If you’re on the fence about going back to school later in life and being an older student, reading about my experiences will give you the confidence to take on this challenge. Without further ado, I present to you…

## My observations and experiences returning to school in my 30s

The day I graduated from Duquesne University in May 2018

## Make sure you get into a decent degree program

Enrolling in a college program as an adult is a serious decision.

You need to be sure that your intended course of study is worth the four years and 5-figure tuition you’re about to invest. You need to be careful not to enroll in a [school that’s just a for-profit online degree mill.](https://thebestschools.org/magazine/online-college-vs-diploma-mills/)

These are just types of places that take advantage of adult students who are strapped for time but want to better themselves.

Be practical. Only major in the latest fad or follow your passion if it fits the criteria below. You’re going to college as an adult to increase your income, grow your network, and get new opportunities, not just to get a degree for the sake of having it.

The time investment will be at least eight 12-16 week semesters. These semesters will not be costly and they will be exhausting.

Here are a few ways to indicate whether your degree is worth the time and money investment:

- **Does it have the words “studies,” “administration,” or “-ology” in it**? If yes, then it’s not rigorous enough to be of any economic value. You’ll be forced to get a master’s degree or higher to see a return on investment with this degree. Since you’re going back to school, I’m assuming that you don’t want to spend four more years there just to have a chance to break even. ***[Note: Do not get a business degree. Business degrees teach you nothing about running one. All they do is signal that you weren’t smart enough to specialize in a topic nor were you ambitious enough to start your own business. Sorry if you have a business degree. If you have one, then you know this is true.]***
- **Does it require you to at least study Calculus 1?** If not, it needs to be more rigorous to be of any economic value. It’s not that worthwhile career paths make daily use of calculus. It’s that the degrees that lead to them tend to require at least the first level of calculus. There is one notable exception.
- **Is it in the medical field?** Nursing doesn’t require Calculus, but the medical profession has exceptionally high demand. Be careful, as many health sciences have a high demand but a relatively low salary.
- **Can you get a paid internship that is higher than minimum wage?** If you ever have to work for free (or for a low salary), even as a student, they are–quite literally–telling you that your work is worthless. Don’t expect to be paid more when you graduate.
- **Is it science, technology, engineering, or mathematics (S.T.E.M.)**? [Despite the recent National Center for Education Statistics](https://nces.ed.gov/), S.T.E.M. is not an automatic guarantee of a high income or career demand. Avoid biology or anything that ends with “sciences,” and you’ll find that most S.T.E.M. programs have a direct or derivative career path that generates a decent income.

Many profitable paths do not require a college education. You can learn a trade, become an auto mechanic, learn to code, or become a salesperson. Some of the best jobs out there don’t require college. But if you want to go to college, then you need to figure out what to study based on the metrics above.

Those student loans you’ll probably need to take out depend on you not messing this up.

By following the suggestions on this list, you’ll prevent yourself from needing even higher education (master’s degree, professional degree, certificate program, etc.) to make enough money to justify the time and money investment.

Now let’s talk more about the money.

## Learn the method I used to earn a physics degree, learn Spanish, and win a national boxing title

- I was a terrible math student in high school who wrote off mathematics. I eventually overcame my difficulties and went on to earn a B.A. Physics with a minor in math
- I pieced together the best works on the internet to teach myself Spanish as an adult
- \*I didn’t start boxing until the very old age of 22, yet I went on to win a national championship, get a high-paying amateur sponsorship, and get signed by Roc Nation Sports as a profession.

I’ve used this method to progress in mentally and physically demanding domains.

While the specifics may differ, I believe that the general methods for learning are the same in all domains.

This free e-book breaks down the most important techniques I’ve used for learning.

 [Get the free book now](https://mind-and-fist.ck.page/0f2b0af82f)

## Figure out how you’ll pay ahead of time

The absolute best-case scenario is that you get some type of scholarship.

This is unlikely as a nontraditional student because many schools reserve scholarships for high school graduates. However, there is always money to be found somewhere.

Specific programs often offer scholarships based on merit. Many medical and teaching fields have tuition reimbursement and loan forgiveness deals. A Google search into “scholarships” and other related terms will expose you to everything available.

Remember: any worthwhile scholarship will be based on merit. This means that you need to make sure that you’re putting everything into each semester and getting the best grades you can.

My transition from a two year to a four-year university was much easier because I got a merit scholarship as a result of my 3.9 community college GPA. The other thing that helped was my G.I. Bill from serving in the Army National Guard.

The military isn’t for everyone, but it’s a fantastic way to fund your education, gain useful skills, and have a potential job while in school. How you’ll pay your bills and feed yourself while you’re in college is something else you need to consider.

You may be able to get away with borrowing enough money to cover your “cost of living” (the official financial aid term) for the first two years of your journey in community college, but if your program is easy enough to where you can work a full-time job and go to school full-time without giving up sleep, then it’s too easy and is probably not worth the cost and time.

You’ll probably have to fill out a FAFSA for financial aid. This will go one of two ways, depending on your life: from a financial perspective, you’re a complete loser and your expected family contribution (financial aid office talk for how much you’re expected to pay) of your tuition is zero.

The other scenario is a bit of a nightmare. You’ve been paying a mortgage or had a respectable salary last tax year. Financial aid is based on your tax returns of the previous year.

If either of these scenarios fits, you probably aren’t getting any government financial aid. At the very least, you aren’t getting as much as you need, and this will almost certainly be a challenging point when you go beyond a 2-year associate’s degree program at a community college.

Even in the best-case scenario, you’re still going to borrow money. The only difference is how much the school lets you borrow and under what conditions. Even with the money you borrow, it may not be enough to finance your education beyond community college. You will need to acquire additional funding.

Me as the poster child of success for the Community College of Beaver County

I worked at a bank during the first two semesters of community college. Then I had to stop working and rely on boxing earnings to cover my cost of living. When I stopped boxing, [I started tutoring high school math and physics](https://edlatimore.com/how-to-get-better-at-math). During all of this, I was still doing National Guard drills on the weekends and collecting that pay.

Even with all of this, there was still a point where I had to pay about $1000 out of pocket. American education is not cheap, so it’s important that you go [back to school for something that will make you employable.](https://www.bachelorsdegreecenter.org/highest-paying-bachelors-degrees-future/)

You need to be reasonably sure that your degree program will lead down a career path where you’re going to make enough money to at least cover the monthly repayment cost for any financial aid you get.

Everyone talks about forgiving student loan debt, but when I filled out the FAFSA paperwork for my financial aid, there was a lengthy section I had to go through about calculating what I was expected to make given my degree choice.

I don’t know if this is mandatory practice, but it’s something that all college students who plan on borrowing money–traditional or nontraditional–should have to do before taking out student loans. A great place to look for this information on the worth of the potential career path your degree program is preparing you for is the [Bureau of Labor Statistics.](https://www.bls.gov/ooh/highest-paying.htm)

If you follow the rules in the first section about degree selection, you shouldn’t have a problem.

## Do as much coursework as cheaply as you can

You can do a large chunk of your degree at a severe cash or time discount. First-time college students right out of high school don’t typically think about the fastest or cheapest way to graduate.

They don’t think about the money because, at that age, most don’t have a reference point for borrowing that much money, let alone figuring out how to pay it back. They don’t worry about finishing college quickly because they’re too busy enjoying the “college experience.”

With fewer nonsense classes to distract me, I could focus and make the Dean's List as a 31-year old

On the other hand, adult students aren’t worried about dorm living, campus events, and frat parties. Adult students are keenly aware of how much money it’s costing them.

Here is a collection of things I researched, attempted, and did to reduce the amount of time and money spent on my bachelor’s degree:

### **Use the College Level Exam Placement (CLEP) tests to cover as many prerequisite classes as possible**

Collegeboard.org runs CLEP and they provide a cheap way to get some credits out of the way. I spent a lot of time studying and building my knowledge up in other subjects so I could simply take a CLEP exam and get credit.

The exams aren’t free, but at $85, they’re still cheaper than even a community college credit. Plus, you won’t have to sit through the class. Just make sure that your potential four-year institution accepts CLEP credits.

### Do your best on math and reading placement exams

Almost all colleges have the option to take a placement exam. [When you go back to school, make sure to take advantage of this.](https://collegeforadults.org/applying-to-college/placement-tests/)

Most kids gloss over these, but you need to take these exams seriously as an adult student.

Testing out of basic English and placing into the highest level class available can save you thousands of dollars and an entire semester’s worth of classes.

### Take advanced placement (AP) exams

When I was going back to school, I ran into an interesting challenge. Some of the schools I was interested in didn’t take CLEP. However, they would take AP credits. Even though I wasn’t in high school, I didn’t let this stop me from figuring out a way to take the exams.

I messaged every AP coordinator in my area that I could find after [using this site to find them](https://apstudents.collegeboard.org/faqs/can-i-register-ap-exam-if-my-school-doesnt-offer-ap-classes-or-administer-ap-exams). I explained to them my age, situation, plan, and my level of preparation. I think I messaged maybe 10. I remember 2 got back to me: one to tell me that it wasn’t possible because I’m a man and they’re an all-girls school, and another to tell me that she would allow it.

After preparing for them extensively, I sat for the AP exam in both physics and calculus. I was a 27-year-old man in army uniform (I had National Guard drills that afternoon), taking the test in a room full of high school students.

Unfortunately, I didn’t score high enough to grab credit for anything, but it taught me a valuable lesson: most rules and limitations are only suggestions.

I don’t know if I’m the only adult student who thought of taking the AP exams to get credit, but based on everything I read and researched, I’m likely one of the only ones to ever go through with it.

### See what credit is offered for SAT and SAT II scores

I came across some schools that offered credit if you achieved a certain score on the SAT or SAT II. There are no rules that say you can’t take these exams as an adult. As long as you pay [Collegeboard.org](https://www.collegeboard.org/) their money, they don’t even care if you show up for the exam.

If your degree program offers credit for a certain score on any of the SAT exams, I strongly recommend picking up a study book and registering for the exam. You can save yourself a lot of money and time if you’re willing to do the work and take the tests.

### Take classes online if you can

I once took a public speaking class online. I didn’t want to take the class, but it was the most insidious type of school requirement–the type that the school wouldn’t accept any transfer credit for. So I had to take it. The good news is that online classes are notoriously easy for the most part.

You can find the answers to many homework and test questions online. Am I advocating you cheat? Yes, because in the real world, [you look up answers to problems you can’t solve.](https://edlatimore.com/problem-solving-process)

Also, challenging classes don’t exist online for this very reason. Or if they do, the exams are proctored in person. But seeing as the university system is still making students pay for classes irrelevant to their field of study, we need to get past these classes as quickly and painlessly as possible.

If you feel bad about approaching irrelevant online classes in this manner, just remember: were it not for these classes, you could finish your degree in half the time at likely a fourth of the price.

They’re basically robbing you. I hope that puts your conscience at ease.

### Talk to professors at your school

During my return to school, I took a semester off to focus on boxing.

I was worried about falling behind on my graduation trajectory, so I talked to my professors about studying on my own, taking the final exam, and getting credit for the exam.

They told me that as long as I didn’t communicate with them about academic matters during the semester, I’d be able to take the final exams and get credit for the class.

I got them to give me the PowerPoint slides for the semester (the classes were Thermal Dynamics and Quantum Mechanics), and they sent me on my merry way. Complications came up and I never followed through, but I got the ok (in writing). This was yet another sign to me that the rules are flexible IF you’re willing to work.

The main lesson from this section is that if you’re willing to ask questions, not make assumptions, and not take “rules” at face value, you can save a lot of time and money.

You may think of other things I didn’t mention on this list to help you get ahead and finish your degree program faster and cheaper than most students.

***[Note: Every suggestion in this section works because, for the most part, grades don’t matter. Don’t kill yourself trying to be the best student or get the best grades. Just pass the class. As an adult, you should know by now that grades don’t matter. Only how you perform in the real world.]***

## The life experience and perspective advantage

I was not emotionally ready when I first tried to get my degree. There is no way around it: [I should not have gone to college.](https://edlatimore.com/4-reasons-why-you-shouldnt-go-to-college)

I was an 18-year-old who’d never left home before and fell into the [drinking and partying crowd](https://edlatimore.com/sobriety-benefits). It wasn’t until I got a little older that I realized how typical this path is for a lot of high school graduates.

[When you’re an adult college student with](https://online.champlain.edu/blog/overcoming-challenges-of-going-back-to-school-as-adult-learner)little life experience, you aren’t interested in many of the distractions plaguing most students. As an 18 year old, I regularly missed class because of a hangover or didn’t study because I wanted to party. Also, as a 30-year-old, it would just be weird if I was out drinking with my classmates.

Your reason for being in school is different than your classmates. Many of them are just there because they’re expected to immediately follow high school with college. You’re there with a definite purpose.

#### When I was in school, I was simultaneously a college student and:

- [Boxing professionally](https://edlatimore.com/boxing-benefits)
- Drilling for the Army National Guard
- Running my website, writing for my blog, and speaking
- Interning

I could handle all of this because of my superior time management.

The busy life of Ed Latimore while doing school.

Despite being busier than most people (and definitely busier than most students), I was able to manage my time and energy because I didn’t waste them on anything that didn’t contribute to my goal.

If you’re worried about how you’ll manage all the work and your other responsibilities, then you’ll have to get creative. Lean on friends and family to help. Eliminate all distractions that do not contribute to your goal.

Once you do this, you’ll be surprised at not only how much help you’ll be able to find, but how much time you have once you get rid of everything that’s not helping you finish school.

## Frequently asked questions about going back to school at 30

Is 30 too old to go back to school?

No. Many people return to school in their 30s and perform better academically than they did when they were younger because they have more discipline, life experience, and clearer career goals.

  Is going back to school at 30 worth it?

Going back to school at 30 can absolutely be worth it if the degree or training leads to better career opportunities, higher income, or a more fulfilling life path. The key is choosing a program with a strong return on investment and realistic job opportunities.

  Can I go back to college at 30 with bad grades?

Yes. Many colleges allow adult students to start fresh or attend community college before transferring into a university. Poor grades from your teens do not permanently prevent you from earning a degree later in life.

  What are the best careers to go back to school for at 30?

Some of the best careers for adult students include nursing, engineering, accounting, computer science, cybersecurity, radiology technology, and skilled trades because they offer strong job demand and relatively clear career paths.

  Is going back to school at 30 hard?

Going back to school at 30 is challenging because adult students often balance work, bills, family responsibilities, and financial stress. However, many older students also have advantages in discipline, focus, and time management that younger students lack.

  How do adults pay for college when going back to school?

Adult students often combine financial aid, scholarships, community college credits, work income, military benefits, employer assistance, and student loans to pay for school. Many also reduce costs by taking transferable credits or online courses.

  Are older students better in college?

Older students are often more focused and motivated because they usually attend college with a specific purpose rather than simply following the traditional post-high-school path. Their maturity and life experience can become major advantages academically.

  Should I go back to school or learn a trade?

That depends on your goals, finances, and career interests. Some careers require a college degree, while many skilled trades and technical careers offer excellent pay without four years of university tuition.

## A recap of things you should know before returning to school at 30 years old

1. Make sure the degree program is worth it
2. Figure out how you’ll pay for college
3. Do coursework as quickly and cheaply as possible
4. Use your life experience and life position to your advantage

A lot of going back to school is about hustle, grit, and seizing opportunities.

If you want it badly enough, you’ll get it. Everything on this list comes down to being motivated and working hard.

Remember: no one ever improved their life by approaching things with low intensity and just going through the motions. Good things come to those who hustle. Stagnation stays with those who wait.

As always, the rest is up to you.

## Learn the method I used to earn a physics degree, learn Spanish, and win a national boxing title

- I was a terrible math student in high school who wrote off mathematics. I eventually overcame my difficulties and went on to earn a B.A. Physics with a minor in math
- I pieced together the best works on the internet to teach myself Spanish as an adult
- \*I didn’t start boxing until the very old age of 22, yet I went on to win a national championship, get a high-paying amateur sponsorship, and get signed by Roc Nation Sports as a profession.

I’ve used this method to progress in mentally and physically demanding domains.

While the specifics may differ, I believe that the general methods for learning are the same in all domains.

This free e-book breaks down the most important techniques I’ve used for learning.

 [Get the free book now](https://mind-and-fist.ck.page/0f2b0af82f)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
