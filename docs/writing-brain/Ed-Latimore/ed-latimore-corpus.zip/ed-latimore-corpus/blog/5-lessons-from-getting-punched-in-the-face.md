# 5 lessons from getting punched in the face

- **Source:** https://edlatimore.com/5-lessons-from-getting-punched-in-the-face
- **Date:** 2022-10-07T21:14:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 10669 chars

## Body (verbatim, study/swipe)

**Watch below**

For 12 years of my life, [I got punched in the face for a living](https://edlatimore.com/how-to-get-into-boxing). Well, that’s technically not the most precise way to explain what a professional boxer does, but it’s accurate enough to get the most miserable and significant parts of the job explained to people.

However, my career as a heavyweight boxer wasn’t the first time I suffered the misfortune of being punched in the face. I didn’t start fighting in the ring until I was 22. The majority of the decade before that was mostly peaceful, but from birth until the age of 13, I’d been punched in the face—a lot.

I don’t want to give the impression that I was the school or neighborhood punching bag.

I grew up in the projects, a.k.a “The hood” or “The ghetto.” Hell, by any other name, is still hell. I lived there until I was 18. I went to school with kids from my projects and other projects until I was 14. In this type of place, fighting was a way of life—and I did not live vicariously.

***Learn more about*** [***my life in the ghetto here***](https://edlatimore.com/the-projects)***.***

I was suspended a lot and, at one point, even threatened with expulsion. Almost all of my offenses dealt with fighting. I can also proudly say that I never started a physical confrontation, at least in the sense that I went looking for a fight.

This doesn’t mean I didn’t throw the first punch, nor does it mean that I got the better of the other guy in every fight. It just means people knew that fighting me wasn’t going to be easy, and there was a significant chance of them getting seriously hurt.

After being on the receiving and delivering end of many ass-kickings and face punchings both as a child and an adult, in both street fights and sanctioned bouts, [I think there’s value in getting punched in the face.](https://edlatimore.com/boxing-training)

Getting punched in the face will teach you more about yourself than ten years of meditation and therapy combined. Here are 5 things you can only learn from getting punched in the face.

## You realize you aren’t fragile

When I was a boxer, I wanted to get touched as soon as possible. I didn’t want it to be too vicious of a shot, but I needed it to cause me discomfort and pain. This pain was necessary because it was proof that I wouldn’t crumble from hurting a little.

The first time you get punched in the face, it hurts. But you’re not dead. If you’re hit by someone untrained (or you are trained), you’re likely not even dazed. You’re just annoyed, angry, and in a bit of pain.

Getting punched in the face is a great way to realize how strong and durable you are because a [punch to the face is always delivered with bad intentions](https://edlatimore.com/how-to-punch-harder-the-physics-and-biomechanical-drills-to-make-you-a-knockout-artist). Whether it’s a confrontation on the street, in a boxing ring, or the octagon, a face punch is meant to do real harm.

Yes, you might get a bloody nose or a black eye, but unless you get sucker punched and you fall and hit your head, there is minimal chance of death from getting punched in the face. You won’t even lose consciousness MOST of the time. It will just hurt, but you’ll still be here.

***Read some mindset tips from boxing—>***[***48 quotes from boxing***](https://edlatimore.com/boxing-quotes-from-ed-latimore)

## You learn to stand up for yourself

Although I fought a lot as a kid, I never started those fights. I’m a pacifist, almost to a fault. I just refused to take anyone’s shit.

Even at a young age, I learned that if people think they can push you an inch without getting any resistance, they’ll try to throw you a mile. Human psychology is such that because you let them take a little, you’re more willing to let them take a lot more.e.

***This article talks about the mentality of people in my neighborhood and school who were like this** →* [***Lessons From The Ghetto: Willingness to Fight***](https://edlatimore.com/lessons-from-the-ghetto-willingness-to-fight)​

Comfort, passivity, and inertia are addictive. There’s a real chance that you’ll continue using them beyond the point of diminishing returns in a manner that borders on compulsion. Even when you know that you should stand up for yourself or others, you won’t because you’ve been chasing the three-headed dragon for so long that you can do nothing else.

The only way to keep from being taken advantage of is to push back whenever you suspect someone is trying you. However, this means [you have to be comfortable with confrontation and the possibility of it escalating.](https://edlatimore.com/how-to-overcome-fear)

After you’ve been punched and you realize it’s not going to kill you, you’re much more likely to stand up for yourself because you don’t fear the outcome of a conflict. In fact, you start to push for the conflict to get to the next level because this attitude teaches you the power of initiative, both psychologically and tactically.

Tactically, the one who strikes first tends to be the one who strikes last. That’s because psychologically, he who is forced to respond and defend himself starts to behave like prey—even if his initial behavior was predatory in nature.

The best self-defense is often a preemptive offense. The hunter is usually ill-prepared for this role reversal, and the prey has a burning desire for revenge.

## You learn the art of righteous suffering

There is nothing in life worth having that comes [without pain and discomfort.](https://edlatimore.com/pushing-through-the-pain) Suffering is the price of admission for a life of satisfaction. If you’re unhappy with your life, you probably need to get punched in the face a few times.

Not literally, in this case—though I always tell guys that the best way to improve your life is to train for a boxing or MMA fight. The reasons why relates to this principle. Training to take a fight is a miserable time.

The training isn’t particularly fun, and getting hit is even less fun. Also, while the environment isn’t abusive, I wouldn’t exactly describe it as supportive either.

But by training and competing, you earn the respect of people who have done it and the admiration of those who wish they could. Fighting isn’t the only arena to gain respect and admiration because you persisted in the face of adversity.

Getting hit in the face isn’t the only way to prove to yourself that you’re made of something. It’s just the most accessible and the one with an immediate negative feedback mechanism to act as a corrective measure.

But you probably shouldn’t get hit in the face too much if you box.

## You learn the power of respect

***“Social media made y’all way too comfortable with disrespecting people and not getting punched in the face for it.”***

***— Mike Tyson***

Getting your ass kicked won’t make you a better person, but it will definitely make you think twice about being a worse one.

Violence isn’t the answer. By the time you reach the point of physical escalation, it’s too late, and higher-order effects will create a scenario where the reaction to disrespect dramatically outweighs the original offense.

People don’t take revenge *just* to get even. They take it to get ahead and set you back.

The best way to avoid this situation is to be incentivized to keep the peace. It starts with treating others with respect, but people also need to know there are consequences to behaving disrespectfully. Violence serves this purpose wonderfully well.

You can always tell who’s never been in an environment where you could get punched in the face for talking recklessly to people.

The *threat* of violence is the real solution to many problems of today.

## It eliminates passive-aggressive communication

Passive-aggressive behavior is for the weak. The number of people who rely on it instead of standing up for themselves is embarrassing.

Passive-aggressive communication tries to get the outcome of winning a confrontation without actually having a confrontation. Classic examples of passive aggression:

- The person who disrespects and insults you until you finally say respond, retaliate, or escalate, and then they go, “I was just joking. Chill out.”

  If you don’t have that joking relationship with a person or it’s over the line (you know if it is or not), check this behavior quickly—even if it means you’ll get punched in the face.
- Then there’s the person who doesn’t directly use your name. “I can’t stand people who [insert something you did].” This is not internet “hit dog” syndrome. This is done in person or in an environment where you’re obviously the subject.

  This person is trying to leave themselves plausible deniability. Fuck that. Make them own it—even if you get punched in the face.
- Then there are people who seriously use sarcasm.

  “Sarcasm” is defined as “the use of irony to mock or convey contempt.” “Irony” is defined as “the expression of one’s meaning by using language that normally signifies the opposite.”

  When you understand this, you see the coward’s plan.

  By saying the opposite of what they really mean to mock, demean, or criticize you, they *feel* like they’re standing tough.

  Until you really do.

Then, this type of person will try to convince you they were being sincere when their tone and body language said otherwise.

Speak directly if you have a problem.

Otherwise, you might run into someone who doesn’t mess around, and then you *really* have a problem.

## Summary

I don’t think getting punched in the face is the BEST or ONLY way to learn these lessons. It’s just that in this modern society, devoid of challenges and obsessed with efficiency and ease, you probably won’t do any of the other things that will develop the grit, resilience, and antifragility that come from taking a righteous crack on the jaw.

Also, I just want to make myself clear: do not street fight **(**[**read my article on why it’s a bad idea**](https://edlatimore.com/how-to-win-a-street-fight)**)**. To get the feeling of being under intense physical pressure to perform in a primal survival manner, join an MMA, kickboxing, or boxing gym. Once there, train for and take a fight. Don’t just go in for exercise.

That’s a safe, legal, controlled way to get exposure to violence.

[And it will improve your life.](https://edlatimore.com/boxing-benefits)

Until then, the rest is up to you.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
