# How often do couples fight?

- **Source:** https://edlatimore.com/how-often-do-couples-fight
- **Date:** 2021-12-08T13:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 9794 chars

## Body (verbatim, study/swipe)

I don’t remember where I learned to argue fairly, but I grew up with plenty of examples of how to do it the wrong way.

You can imagine how people in a constant state of survival mode overcome their differences.

My examples consisted of conflict resolution by manipulation, name-calling, and often violence.

It made me reactive and conflict-avoidant. So I had to learn something different if I wanted a different outcome from the countless broken relationships I was used to.

One thing I learned was that everybody fights, even happy couples.

But somewhere along the way, ‘’all couples fight’’ became the mantra of those trying to convince themselves they aren’t in bad relationships. Even once the red flags turn into blazing red flames.

In this article, we’ll dive into the deeper reasons couples fight and how much fighting you should really be worried about.

## What is a healthy amount of fighting?

Healthy relationships go through cycles. You may find yourself in what feels like the honeymoon phase several times over the years. You could also feel like you’re nearing a break-up and still be in what some would consider a healthy relationship.

Men and women are so fundamentally different that it’s impossible for you to see eye-to-eye on everything. So how often couples fight is determined by personality and each person’s style of dealing with conflict. The trick to managing this aspect of your relationship is to anticipate this and have a constructive style of disagreement.

In other words, healthy relationships are determined by how well you manage your differences.

## Fundamental Differences

How you disagree in a relationship determines how happy you can be because conflict is the one guarantee you have.

According to research by psychologist and relationship expert, John Gottman, couples have perpetual problems that stem from unsolvable core differences. More specifically, he says 69%[1](#fn:1) of the arguments you have in your relationship are the same issues all stemming from these core differences.

I grew up seeing explosive fights that went nowhere and had to unlearn much of what was taught to me directly and indirectly. However, most people never evaluate how their development shapes the way they handle problems until it’s time for relationship counseling. The result is a never ending cycle of bad relationships.

Another approach to this concept is the idea that conflict management lies on a spectrum. What side of the spectrum you reside on is determined by your cognitive development.[2](#fn:2)

For example, the following personality types will always have issues:

1. Cool-headed vs. reactive
2. Instant vs. delayed gratification
3. Spontaneous vs. a need for structure
4. Independent vs. co-dependent
5. Planners vs. action takers

## Destructive disagreements

Without adequate management of your differences, even potentially healthy relationships can devolve into name-calling, throwing things, and all-out emotional abuse.

Disagreements that go nowhere often involve over-talking who said what or who became angry first.

Some further examples of destructive disagreements are:

- Defensiveness and not taking responsibility for your behavior
- Shutting down and refusing to talk or engage during an argument then never discussing the argument later
- Belittling and contemptuous emotional abuse from a place of superiority
- Constantly insulting and criticizing your significant other’s behavior

To ensure that I am always giving my significant other what she needs, I had to learn to take care of the most important things first: Myself.

I know this seems counterproductive but let me explain. Prioritizing myself over anything else doesn’t mean that I neglect things that are urgent and important. It only means that I make sure that 1.) this is the relationship I want to be in and 2.) I’m doing what it takes to make sure that I can take the relationship seriously.

If it’s a relationship I want to be in, then I’ll do what it takes to make sure the relationship stays in a territory that helps us both enjoy it.

## Constructive disagreements

A constructive style of disagreement is one where you try to solve the problem rather than prove that you’re right. A destructive style of disagreement is where you try to be right rather than solve the problem. The latter inspires new solutions. The former repeats old problems.

Once I learned to value the relationship and the commitment over the individual, everything changed for me. When you value the strength and longevity of the relationship, you do what’s best to maintain it versus doing what will make either of you feel good in the moment. So taking this level of responsibility, I can be who I need to be to take the relationship seriously.

This is similar to how I view arguing fairly or having constructive disagreements. A fair argument is good for the relationship because it clearly identifies the problem and doesn’t bring in anything that might put an unnecessary strain on the relationship.

Ultimately, managing the differences between you and your significant other is about practicing empathy and seeing the other person’s perspective.

Here are a few examples of what this looks like during a disagreement:

- Not overly emotional and always looking for areas of common ground
- Never insulting or disrespectful but may argue often and often while laughing
- Avoids competing with each other and always seeking to see the other person’s point of view

## The secret to great relationships

I cannot emphasize enough the importance of choosing the right person. A bad relationship can make your life unnecessarily hard and reduce your body’s ability to fight off disease.[3](#fn:3) No matter how good your communication skills are, it takes two to tango.

A dead giveaway that you’re choosing the wrong one is the line, “I’m not here for hookups, I’m looking for something serious.” Or a guy that leads interactions with overly sexual messages. Check out my blog, [you can’t force relationships to develop](https://edlatimore.com/you-cant-force-relationships-to-develop), to understand why these are just weak attempts to control the mating ritual and why they never work.

Men tend to believe that any woman is relationship material and generally don’t know [how to get into a relationship](https://edlatimore.com/how-to-get-into-a-relationship) with the right woman.

Though it doesn’t solve every problem, choosing the right person has to be a baseline defense when selecting a partner. Once you discover the red flags to look for in a partner, find out if you have any of them [here](https://edlatimore.com/red-flags-in-men), avoid them like the plague.

When you pick the right person—or rather, avoid picking the wrong person—you eliminate many of the reasons couples fight and ultimately break up. This, of course, requires knowing yourself well enough to pick someone who is a good match and the discipline to reject anyone who isn’t.

## Being better for each other

Building lasting relationships requires you to be willing to be wrong. It also requires you to take the lead, improve your communication skills, and be willing to see your significant other’s point of view. Pay more attention to the quality of your fights than the quantity. Arguing often is not a sign that your relationship is in trouble but it could be.

Are you finding common ground or are you constantly taking low-blows? Shutting down and ignoring each other? Or simply tired of ‘working on it’?

Could your relationship be headed for a dumpster fire if you fight often? Sure. But it’s definitely going there if you aren’t willing to work on it to get better.

## Get Your Life Together With The Essays of Power

I don’t know you, but I know you.

I know that you’re tired of feeling weak, being a victim, and having no control over the direction of your life.

I know you because I was once you.

I used to be stuck on the hedonistic treadmill of mediocrity. Always drunk, always broke, and always looking for the next piece of cheap entertainment and distraction.

Then one day, I changed my entire life around.

I took responsibility for my personal development and started living the best life I possibly could. I learned how to:

- Live with purpose
- Think with clarity
- Face the my demons
- Fix my finances

Unlike a lot of other motivational gurus, I’ve been to the bottom and I clawed my way back out. It wasn’t easy and I wasn’t sure if I’d just become another statistic along the way, but I think I have made tremendous progress.

I learned the hard way, but I can break it down so you can learn it the easy way…

 [Get The Mind And Fist Essays Of Power](https://gum.co/GDlZd)

---

### References

​

1. Miller, A. [Can this marriage be saved? Monitor on Psychology](http://www.apa.org/monitor/2013/04/marriage), *44*(4). 2013, April. (accessed November 21, 2021). [↩](#fnref:1)
2. Dashnow, D. *[Couples Therapy Inc. “The Neuroscience of Perpetual Arguments”](https://www.couplestherapyinc.com/the-neuroscience-of-perpetual-marital-problems/)* (accessed November 21, 2021). [↩](#fnref:2)
3. Hysi, Greta. (2015). [CONFLICT RESOLUTION STYLES AND HEALTH OUTCOMES IN MARRIED COUPLES: A SYSTEMATIC LITERATURE REVIEW](https://www.researchgate.net/publication/304246577_CONFLICT_RESOLUTION_STYLES_AND_HEALTH_OUTCOMES_IN_MARRIED_COUPLES_A_SYSTEMATIC_LITERATURE_REVIEW). Research and Education “Challenges towards the future” ICRAE 2015. 2. (accessed November 22, 2021). [↩](#fnref:3)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
