# The Tao of Jeet Kune Do: 21 quotes & 6 big ideas

- **Source:** https://edlatimore.com/tao-of-jeet-kune-do-quotes
- **Date:** 2022-03-18T10:51:01.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 19682 chars

## Body (verbatim, study/swipe)

The Tao of Jeet Kune Do was perhaps Bruce Lee’s greatest contribution to the world of martial arts. He began writing the book in 1970 while he was recovering from a back injury\* that nearly ruined his acting career before it even got started.

\****Note: For stylistic effect, the 1993 biopic movie about his life “Dragon: The Bruce Lee Story” showed this injury caused by a fight. The reality is that Bruce injured his back performing the “Good morning” exercise with weights that were too heavy, too often, and without properly warming up. The real story doesn’t make for good cinema.***

The book is essentially a treatise on all aspects of fighting. Specifically, it was a combination of Bruce Lee’s notes and commentaries on the fighting system he was developing (Jeet Kune Do or “JKD” for short) and its comparison to other fighting systems.

Bruce Lee kept various notes throughout the development of his fighting system that would also be used in The book. Many of these notes were “sudden inspirations” which were incomplete and lacked any kind of a construct. The combination of the “core set of writings” and the “disparate notes” make up the text Tao of Jeet Kune Do.

As a result, the book doesn’t read like a narrative or even a complete work. Rather, it’s a set of observations and notes, written in a flowing style, as Bruce sporadically captured many of these inspirations.

The Tao of Jeet Kune Do is one of my favorite books because fighting is an excellent analogy for many things in life. Bruce Lee captures many poignant observations from martial arts that apply to many areas of life.

This book is a must-have for any martial artist or philosopher out there. Below I’ve collected my favorite quotes from The Tao of Jeet Kune Do, along with my own extrapolations and explanations.

## 21 quotes and 6 big ideas from The Tao of Jeet Kune Do

The Tao of Jeet Kune Do

## **Self-Knowledge**

- **“The consciousness of self is the greatest hindrance to the proper execution of all physical action.”**

  Most people aren’t thinking about you. Most people don’t even know that you exist. You’re worried about looking foolish or falling out of favor with them, which keeps you from executing in your life.

  One day they’ll die. So will you. What they think is ephemeral. What they do is ephemeral. These conditions apply to you as well.

  Don’t let something temporary and meaningless ruin your temporary and meaningless time on this planet.
- **“Relationship is understanding. It is a process of self-revelation. Relationship is the mirror in which you discover yourself — to be is to be related.”**

  We only develop and learn about ourselves in relation to other people. We learn the most vital skill, communication—verbal and non-verbal—by constant interaction with others.

  We learn to love, respect, care for, and empathize by interacting with others. Even our aims in competition depend on understanding our opponent. And how we treat our opponent determines whether he becomes our enemy.
- **”Self-expression is total, immediate, without conception of time, and you can only express that if you are free, physically and mentally, from fragmentation.”**

  Whenever you hold part of yourself back, you’re holding all of yourself back. Expression is only possible when the totality of your being is free to be. Practically speaking, this is expressed in the idea of the saying, “A chain is only as strong as its weakest link.”

  You can only be as effective as your most ineffective part. While you may get lucky a few times initially, as the stakes get higher, more of your weaknesses will be revealed. This is a natural result of more of you being demanded to meet your challenges.
- **“To know oneself is to study oneself in action with another person.”**

  We can learn a lot from observing how we interact with other people but in a rather unsuspecting manner.

  When a character trait in another person pleases you, it’s one that you wish you had. When a character trait in another person annoys you, it’s one that you have and haven’t made peace with yet.

  In this way, one of the highest forms of self-development is awareness of the reactions you have when interacting with other people.

## **The state of mind to see the truth**

- **“To obtain enlightenment in martial art means the extinction of everything which obscures the ‘true knowledge,’ the ‘real-life.’“**

  When you remove what’s in the way, the way becomes passable. When you remove what blocks your sight, then all things become visible.

  Rather than focus on getting more to do more, a worthwhile investment is to remove and reduce what is in your way.

  This way, there is nothing left to keep you from your goals. Sometimes the solution isn’t to do more or to try harder. It is to be more effective, efficient, and to focus on removing the unnecessary or intrusive.
- **“The oneness of all life is a truth that can be fully realized only when false notions of a separate self, whose destiny can be considered apart from the whole, are forever annihilated.”**

  The fastest way to know the truth is to stop harboring falsehoods. In this way, whatever is left is real, honest, and true.

  When you can do this, you no longer can be threatened by anything because only that which is vulnerable and temporary can be threatened, and the truth is neither of those things.

  This reminds me of a line from one of my favorite books, The Course in Miracles: “Nothing real can be threatened. Nothing unreal exists.”

  The goal is to only focus on what is real to you. If you do this to the best of your ability, you will always know peace, even if you accidentally align yourself with the counterfeit.
- **“To see a thing uncolored by one’s own personal preferences and desires is to see it in its own pristine simplicity.”**

  Everything you see and experience is not pure.

  It is filtered through your perceptions, experiences, and expectations. Furthermore, merely by taking part or observing something, you influence the properties you observe. It’s impossible to observe something without becoming part of your observation.

  This idea has [an analog in physics](https://edlatimore.com/is-physics-hard-how-to-study-and-learn-basic-physics), called the uncertainty principle. The act of measuring always influences what’s being measured. The same holds for our perceptions. The idea then is to reduce our perception as much as possible to get as close to honestly seeing what’s in front of us as possible.

## **Formless artistry**

- **“Art is an expression of life and transcends both time and space. We must employ our own souls through art to give a new form and a new meaning to nature or the world.”**

  Art is created with an emotional component. Otherwise, it is merely technical. The artist feels their way through parts with the intuition that’s been honed by experience but is guided by emotion.

  A beautiful quality about our emotions is that they are immune to the passage of time. While we can forget the things that cause our emotions, our emotions don’t care how long ago something was, how far away we are from it when it happens, or how far into the future something could occur. If we emotionally attach to something, we feel it shares the exact time and space with us.

  Therefore, art—something that can only be created with emotion—allows us to create something that transcends dimensional limitations. Time and space are nothing for the feelings that an artist’s performance inspires.

\* \*\*“Art is never decoration, embellishment; instead, it is a work of enlightenment. Art, in other words, is a technique for acquiring liberty.”\*\*

True artists never create for the sake of vanity. They may have developed a sense of vanity towards themselves, but the work is never created in vain. This is a valuable lesson about art and how to add more of an artistic flair to their life.

To create art, create to free your ideas and emotions from the restrictive cage of your mind and heart. If you view creation as an act of liberation of your most deeply cherish thoughts and feelings, then you have the ability to artistically express yourself in a variety of vocations.

You don’t need a canvas or a musical instrument. You simply need the tools of your trade and intention. \* \*\*“Art calls for complete mastery of techniques, developed by reflection within the soul.”\*\*

This reminds me of one of my favorite lines from my favorite movies. In “Man on Fire”, Ray Burn (played by Christopher Walken) describes the revenge that his friend John Creasy, retired special forces and CIA operative (played by Denzel Washington), is about to take on the cartel that kidnapped the girl he was in charge of protecting (played by Dakota Fanning).

\*“A man can be an artist at anything. It depends on how good he is at it. Creasy’s art is death—and he’s about to paint his masterpiece.”\*

The idea is that art is an expression of skill. Rather, art is a fusion of skill and passion. It’s possible to be passionate but lack the skill (a hobbyist) or skillful but lack passion (a technician), but combining the two creates the artist.

Skill is built, but passion is revealed. This means that technical mastery precedes stylistic expression, but technical mastery alone doesn’t make you an artist. My boxing coach always said, “I can teach you how to fight, but I can’t make you a fighter.” The idea is captured perfectly by this quote.

It’s not enough to know “how.” You must have a powerful “why” if you want to be more than a skilled operator. If you want to be more than a passionate hobbyist, you must understand “how” just as much as you are driven by “why.”

## Learn from more books in less time with Shortform

I don’t normally think you should read the summary instead of the entire book, but Shortform has completely changed my mind.

Their summaries are high-level works of art, complete with commentary and additional insights to help you bridge together information and concepts presented in the books.

But that’s not even the best part…

Each summary has an audio version so that you can listen on the go. You’re able to enjoy the summaries the same way you enjoy your favorite podcast! And they cost less than you’d spend on just one book.

Save time and money with Shortform. Use the link below to save 20%

 [Check out Shortform!](https://shortform.com/latimore)

## Martial arts analogies to life

- **“The great mistake is to anticipate the outcome of the engagement; you ought not to think of whether it ends in victory or defeat. Let nature take its course, and your tools will strike at the right moment.”**

  Worrying about the outcome of an engagement forces your mind to leave the moment where its full energies are required. Although the goal is to win, focusing on that goal distracts yourself from the process necessary to win.

  There is nothing you can do about anything beyond your control. You don’t control your environment or the preparation of your opponents and adversaries. All you control is yourself and your approach to the challenge. While it’s natural to worry if you’ll be successful, it’s also pointless and distracting.

  If you have prepared, then you’ll be prepared. if you are ready, then you are ready. But there is nothing you can do about anything beyond yourself, so putting your mind on things you can’t control takes energy away from things you can.
- “**While being trained, the student is to be active and dynamic in every way. But in actual combat, his mind must be calm and not at all disturbed. He must feel as if nothing critical is happening.”**

  This is a more specific way of saying, “Easy training, hard fight. Hard fight, easy training. [In training for a fight](/boxing-training), we push ourselves as hard as possible. Ideally, harder than the actual fight will be. This level of conditioning is more for the fighter’s mindset than his physical capabilities.

  During the fight, remaining calm under fire is of supreme importance. In fact, one of the hallmark differences between experienced fighters and novices is the ability to stay calm under fire. This is the attitude that we want to take into life.

  We must learn to push ourselves in all areas as a form of training so that the business of living is simple. Or, at the very least, we can remain calm when our surroundings aren’t. By making a habit of embracing complex and/or high-stress situations, we become more comfortable with this and the rest of life seems easy.

  There is a tremendous benefit to this manner of living.
- **“Instead of facing combat in its suchness, then, most systems of martial art accumulate a “fancy mess” that distorts and cramps their practitioners and distracts them from the actual reality of combat, which is simple and direct. Instead of going immediately to the heart of things, flowery forms (organized despair) and artificial techniques are ritualistically practiced to simulate actual combat. Thus, instead of “being” in combat these practitioners are “doing” something “about” combat.”**

  Focus on what matters, what is effective, and what actually makes a difference. Everything else is, at best, trivial and, at worst, distracting. This quote made me think of religion.

  Every religion has rituals, but I can’t imagine that whichever deity they worship cares about them. Even logically, an omnipotent and omnipresent being doesn’t care about your confession, whether you mix meat and dairy or eat meat on Friday in certain parts of the year. Not only are those things not important to be a better person, but they also create systems of judgment and exclusion that dilute your character.

  I don’t claim to be a religious expert. Still, my first thoughts shifted to religion and how we ruin our spiritual connection and connection with our fellow man by focusing on what doesn’t matter to the spiritual aspect. Instead of being spiritual, we become people who are doing something we think is about spirituality.

  This thought process can be applied to many things. The authentic connection and immersion will always be challenged by the superficial demonstrative and study. The challenge is to do versus only appearing to do.
- **“When you get down to it, real combat is not fixed and is very much “alive.” The fancy mess (a form of paralysis) solidifies and conditions what was once fluid, and when you look at it realistically, it is nothing but a blind devotion to the systematic uselessness of practicing routines or stunts that lead nowhere.”**

  There is nothing static about anything that requires real-time interaction. This means the entire business of living and interacting with people can not be reduced to a simple formula. There are too many variables and probability functions to consider.

  Those who want a simple method or formula for success will always be doomed to fail.

  This reminds me of the criticism levied against the book “Rich Dad, Poor Dad”. People say that the book doesn’t tell you exactly what to do to become rich. That’s because there are so many different variables at play and things change so often that the most honest thing the author can do is give you a way to think rather than an exact formula that could be irrelevant in a year or less.

  Always seek a dynamic strategy rather than a rigid tactic.
- **“The fighter is to always be single-minded with one object in view—to fight, looking neither backward nor sideways. He must get rid of obstructions to his forward movement, emotionally, physically or intellectually.”**

  We do not worry about what has happened or will happen in the future. We simply live in the moment.

  When your attention drifts to moments that are not happening now, then you lose the strength that comes with a coordinated mind.

  To be at your best, you must be single-minded in the present. This type of focus does not even consider obstructions on the path. It simply looks past them in pursuit of the goal.

## **Patterns and systems**

- **“Set patterns, incapable of adaptability, of pliability, only offer a better cage. Truth is outside of all patterns.”**

  When you initially create or perform, it’s easier to rely on patterns and systems. This way, you can get enough repetitions without frustration or failure. However, to achieve distinction, you’ll have to step outside the system and create something new and noteworthy.

  The only way to do this is to create something new. Or, at the very least, think outside of the system and patterns you have come to rely on. The best way to do this is to master the system itself.

  Technical expression always comes before stylistic expression.
- **“One can function freely and totally if he is “beyond the system.” The man who is really serious, with the urge to find out what truth is, has no style at all. He lives only in what is.”**

  You have to learn the rules before you can break the rules.

  By learning the rules, you understand the system and how it’s built. In fact, by learning the system, you may even gain a place inside of the system. And it’s from within the system that you can tear it down.

## **Total comprehension**

- **“The height of cultivation runs to simplicity. Half-way cultivation runs to ornamentation.”**

  You understand a subject well when you no longer overcomplicate your explanation of it. You’ve grasped a skill when you no longer make extra moves while executing. You’ve mastered your emotions when you experience them as long as necessary.

  A sign of cultivation is efficiency, and a sign of efficiency is simplicity. However, when you don’t know something well enough to simplify it, you’re left but no choice but to make it more complicated. This often isn’t intentional. Rather, it’s merely the result of confusion and inefficient connections between the supporting skills and knowledge.

  This can only be fixed with training, reflection, and repetition.
- **“We shall find the truth when we examine the problem. The problem is never apart from the answer. The problem is the answer — understanding the problem dissolves the problem.”**

  You will find that any problem you have, the solution is embedded in that problem. This isn’t as complicated, unbelievable, or profound as it seems. The problem is telling you exactly where you need to focus your attention.

  This is especially true for personal problems. Your ego often prevents you from seeing the solution because that often means admitting your role in creating the calamity. And once you can accept the role you’ve played, you have to accept the burden of what it will take to fix.
- **“Awareness has no frontier; it is a giving of your whole being, without exclusion. Concentration is a narrowing down of the mind. But we are concerned with the total process of living and to concentrate exclusively on any particular aspect of life, belittles life.”**

  All of life is important. Lee is telling us not to neglect any part of our development. More specifically, he’s warning us not to overly concentrate on any particular part of life.
  ​​
  This means that your family should be no more important than your business, should no more important than your health, should be no more important than your citizenship, and so on.

  All areas of your life need to be at a basic level of functionality to get the most out of living.

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
