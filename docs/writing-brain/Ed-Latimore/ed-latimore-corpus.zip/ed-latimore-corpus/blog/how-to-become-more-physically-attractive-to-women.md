# How to become more physically attractive to women

- **Source:** https://edlatimore.com/how-to-become-more-physically-attractive-to-women
- **Date:** 2022-07-26T14:00:00.000Z
- **Captured:** read-only public web scrape 2026-06-20 18:43
- **Length:** 12273 chars

## Body (verbatim, study/swipe)

If you’ve been following the blog, you know that I recently discussed the importance of being physically, mentally, and emotionally strong.

Handling these three areas is a daily fight against disorder and entropy.

Working on your attractiveness is also a constant fight against letting yourself go. It signals to women and the world that your life and health are in order.

When I was drinking regularly, it’s no coincidence that I also wasn’t on top of my grooming and wardrobe the way I am now that I’ve been sober for years. My life and my health weren’t in order.

Women provide immediate feedback when you’re at your most attractive. They also provide immediate feedback when you let yourself become an uncaring, ungroomed slob.

But the results don’t stop with women.

Physically attractive people even earn 15% more in the workforce (men included).[1](#fn:1)

The tips below will make you a physically attractive man who is committed to resisting mediocrity.

## Get in shape for real

I had to add the qualifier “for real” because men are also good at lying to themselves about their physical condition. Ignore the idea of the “Dad Bod” being the most sought-after body type.

Women in a study were shown photos of shirtless men with their faces obstructed. All 160 of these women ranked men that had muscle-toned bodies the highest.[2](#fn:2)

You probably didn’t need a double-blind study to know that.

However, there’s zero reason to become a bodybuilder unless you desire to. Find a physical outlet you can dedicate yourself to, stick to it five to six times per week, and get in the best shape of your life.

You already know that boxing was a lifesaver for me.

Boxing gets you in shape and wages war on your weaknesses. You’re rewarded not just with a stronger mind, but also a body that’s the epitome of [what women find physically attractive](https://edlatimore.com/how-to-be-an-attractive-man).

I advise every man to train in a martial art.

If that’s not for you, choose another physical activity that pushes your mental and physical limits. Some good options include:

- Weight training and kettlebells
- High-Intensity Interval Training (HIIT) Exercises
- Rock climbing

Any workout that strengthens muscle, burns body fat and [builds testosterone will naturally](https://edlatimore.com/mita-nutra-man-greens-review) improve your appearance and confidence.

Women are naturally drawn to and follow men with this mixture of magnetism. [Read here to learn how to take the lead in long-term relationships.](https://edlatimore.com/how-to-take-the-lead-in-a-relationship)

## Become more attractive without turning into a d-bag

 [Get the short free guide here](https://mind-and-fist.ck.page/ae776819a8)

## Build a strong jawline

Sharp, defined jawlines are masculine and inherently attractive to women.

Consistency in the gym will help you accomplish this.

A study found that a Body Mass Index (BMI) of 24 yielded the most attractive facial structure for a man.[3](#fn:3)

I’ve also gotten results from [chewing mastic gum to build my jaw muscles](https://edlatimore.com/mastic-gum-review). This gum is made of thick sap that comes from the mastic tree. This resin is sugar-free, and about ten times harder than any gum you’ve ever chewed.

It strengthens the muscles in your face when you chew it, giving your jaw more contour and definition. It’s not the best tasting gum I’ve ever tried but it gets results.

## Improve your wardrobe

The way you dress signals high status and taste and makes you more likely to foster romantic attraction.

I’m not going to tell you to visit New York Fashion Week for ideas…

… But learning how to be a man of style is an important factor for dudes that want to stand out to attractive women.

Wear men’s clothing that is:

- Timeless and neat
- Made in colors that fit your skin tone and style
- Age-appropriate and fashionable
- Clean, ironed, and not faded
- Tailored or otherwise fitted to your body

Develop a mix of casual, dressy, and dress casual outfits. Jeans and t-shirts are great, but try to branch out of your comfort zone.

For a lot of guys, branching out of comfort and sports clothing is like pulling teeth.

Never hesitate to invest in something that can change so much about how you look and feel about yourself.

## Invest in fragrance

Your fragrance communicates attractiveness to women on a carnal level. Find a daily-wear bottle of fragrance that blends with your natural body chemistry.

It’s the kind of shopping you have to do in person because we all have an individual-specific scent profile.[4](#fn:4) This means a cologne that works wonders for you might smell horrible on me, and vice versa.

Get to know the different categories of men’s fragrance:

- Ouds have a woody, damp, intense smell
- Eau Fraiche is a lightweight, casual kind of fragrance (It means fresh water)
- Eau de toilette is a strong, longer-lasting form of fragrance

You don’t have to blow a lot of money on fragrance, but purchase something that is high-quality and age-appropriate. Cologne kits often come with deodorant and other products that help with body odor.

## Take care of your hair

Find a hairstyle that fits your personality, frames your face, and highlights your best features. Go to the barber or stylist regularly, and always make sure your hair is washed and conditioned.

Hair has always been one of my favorite areas of self-care.

Growing up, it was basically a matter of self-preservation…

You couldn’t come outside in my neighborhood with a sloppy haircut unless you were prepared to get peppered with several jokes at your expense.

Women might not clown you for your bad hairdo, but they’re attracted to men who pick a style and get the most from it.

This means handling your hair emergencies.

I realized I was balding one day in my twenties. A friend pointed it out to me so matter-of-factly one day that it hit me like a gut punch. Genetics are undefeated, so I tried out some solutions that gave me results.

Platelet rich plasma (PRP) treatments or [laser cap therapy](https://edlatimore.com/bosley-revitzlizer-272-laser-cap-review) wasn’t commercially available at the time.

I started applying minoxidil and finasteride topically since they’re both FDA-approved. These results were OK, but I really turned things around when I decided to get a Follicular Unit Extraction (FUE) transplant.

With this procedure, doctors take hair-growing tissue from other parts of your scalp and implant them in areas of balding and thinning. I paid $18K for two separate implant appointments, and after about a year, the new hair growth was just as thick and healthy as the rest of my hair.

I consider that money well spent when you consider these before and after photos:

15 months after hair transplant

bosley before and after ed latimore fue

While you’re at it, check out this post on other tips on [how to reverse hair loss before it’s too late.](https://edlatimore.com/how-to-prevent-hair-loss)

## Develop a grooming routine

When I handle my grooming, I feel in control of the details in my life. Caring for your facial hair frames your jawline, eyes, and teeth in a way that women find attractive.

Wear your facial hair in a way that accentuates your facial features and brings the look to life.

It doesn’t mean you have to grow a full beard. Women actually find heavy stubble the most attractive.[5](#fn:5) Just make sure that it’s well-kept and doesn’t just look like you never shave.

Women also find men with redder, more vibrant skin the most attractive.[6](#fn:6) This skin tone signifies healthy blood flow, vibrancy, and hormone health. Regularly washing and moisturizing your skin will give it that flush, reddish, natural tone and glow.

Your skincare kit should include a good:

- Facial cleaner
- Face oil
- Exfoliant

Wash your face in the morning and before bed. In between cleanings, apply a few drops of the face oil to your skin by rubbing small circles.

I highly recommend Noble Body face oil for men. You can get it [here through my link](https://noble-body.com?aff=33), (I get a small cut of each purchase, it helps to pay the bills).

Use an exfoliating product twice a week to clean deep into your pores to make your skin clear and healthy.

You’ll also improve your skin health and good looks by cleaning up your diet and eating plenty of fruits and leafy green vegetables. These foods will give you healthy, glowing skin:

- Avocados
- Blackberries
- Blueberries
- Strawberries
- Hemp, pumpkin, and flax seeds
- Bananas
- Leafy green vegetables

## Fix your body language and posture

Body language is one of the [most consistent ways to communicate attractiveness to women](https://edlatimore.com/relationship-advice). Men who maintain an upright posture and open body language denote personality traits like dominance, strength, and confidence.[7](#fn:7)

Sitting up straight and standing with your shoulders back and your chin raised can make you feel more outgoing and charismatic. Your ability to maintain eye contact, a sense of humor, and a self-assured smile is an instant turn-on to women.

Visit the chiropractor for an adjustment to make sure your spine is properly aligned and elongated. This makes it far easier to maintain the correct posture.

Check out this post on [how to grow your personal magnetism, self-confidence, and charisma.](https://edlatimore.com/how-to-be-charismatic)

## Become more physically attractive to women

The key in it all is to be intentional about your presentation.

Improving your physical attractiveness builds confidence that can help you in your interactions with the opposite sex.

Life gets pretty amazing when you choose to actively work on yourself. Set yourself apart from the pack by making these adjustments.

As a final reminder, if you need help with your fashion sense, you should check out my buddy Tanner Guzy’s men’s style course, *Dress Like a Man*.

## Become more attractive without turning into a d-bag

 [Get the short free guide here](https://mind-and-fist.ck.page/ae776819a8)

---

### References

1. *IZA World of Labor*. New report: Physically attractive people earn 15% more than plainer colleagues. June 29, 2015. <https://wol.iza.org/press-releases/does-it-pay-to-be-beautiful>. (Accessed May 17, 2022) [↩](#fnref:1)
2. *Boss Hunting*. Which Male Body Shapes Do Women Find The Most Attractive?. March 10, 2022. <https://www.bosshunting.com.au/lifestyle/relationships/male-body-shapes-most-attractive/> (Accessed May 18, 2022) [↩](#fnref:2)
3. *Elite Daily*. Here’s How Much Weight You’d Need To Lose For Anyone To Even Notice. December 14, 2015. <https://www.elitedaily.com/news/weight-loss-face-study-people-notice/1319310> (Accessed May 18, 2022) [↩](#fnref:3)
4. Lenochová, Pavlína. Vohnoutová, Pavla, Roberts, S. Craig. Oberzaucher,Elisabeth. Grammar, Karl. Havlíček, Jan.\_National Library of Medicine. \_Psychology of Fragrance Use: Perception of Individual Odor and Perfume Blends Reveals a Mechanism for Idiosyncratic Effects on Fragrance Choice. March 28, 2012. <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3314678/> (Accessed May 17, 2022) [↩](#fnref:4)
5. Rowland, Hannah. Burriss, Robert. *National Institute of Mental Health*. Human colour in mate choice and competition. May 22, 2017. <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5444069/> (Accessed May 17, 2022) [↩](#fnref:5)
6. Vacharkulksemsuk, Tanya. Reit, Emily. Khambatta, Poruz. Eastwick, Paul W. Finkel, Eli J. Carney, Dana R. Proceedings of the National Academy of Sciences of the United States of America (PNAS). Dominant, open nonverbal displays are attractive at zero-acquaintance. March 28, 2016. <https://www.pnas.org/doi/10.1073/pnas.1508932113> (Accessed May 18, 2022) [↩](#fnref:6)
7. Ohio State University. *Science Daily*. Body Posture Affects Confidence In Your Own Thoughts, Study Finds. October 5, 2009. <https://www.sciencedaily.com/releases/2009/10/091005111627.htm> (Accessed May 18, 2022) [↩](#fnref:7)

Written by

Ed Latimore

Ed Latimore is a best-selling author, professional heavyweight boxer, and physicist. He writes about self-improvement, sobriety, fighting, and the lessons he learned growing up in the projects of Pittsburgh.

[Follow @EdLatimore](https://x.com/EdLatimore)
